import glob
import subprocess

file_list = glob.glob('*.cpp')
for x, name  in enumerate( file_list):
#	print x
	proc = subprocess.Popen(['./select-headers.sh', 'CPP_Headers.h', name, 'g++-trunk'])
	proc.wait()
