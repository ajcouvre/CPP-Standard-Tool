
struct X {

template<std::size_t> X* alloc();
template<std::size_t> static X* adjust();

};
template<class T> void f(T* p) {

T* p1 = p->alloc<200>();
T* p2 = p->template alloc<200>(); // OK: < starts template argument list
T::adjust<100>();
T::template adjust<100>();

// ill-formed: < means less than
// OK: < starts template argument list

// ill-formed: < means less than

}

