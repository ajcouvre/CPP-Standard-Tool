int main()
{
struct X {

int i;
static int s;

};

void f() {

using X::i;

using X::s;

}


return 0;
}
