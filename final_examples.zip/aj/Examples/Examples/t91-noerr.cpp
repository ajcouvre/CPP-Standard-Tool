
struct B { };
struct D : private B { };
void f() {

}

static_cast<D*>((B*)0);
static_cast<int B::*>((int D::*)0);

// Error: B is a private base of D.
// Error: B is a private base of D.

