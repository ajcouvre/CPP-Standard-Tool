
6

struct B {

virtual void f() throw (int, double);
virtual void g();

};

};

struct D: B {

void f();
void g() throw (int);

// ill-formed
// OK

The declaration of D::f is ill-formed because it allows all exceptions, whereas B::f allows only int and
