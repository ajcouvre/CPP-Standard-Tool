int main()
{
typedef int complex;
class complex { /* ...

*/ };

// error: redeﬁnition

8


return 0;
}
