
template<class T1, class T2, int I> class A<T1, T2, I> { };
template<class T1, int I> void sort<T1, I>(T1 data[I]);

// error

