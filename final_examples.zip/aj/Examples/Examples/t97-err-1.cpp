new int * i;

// syntax error: parsed as (new int*) i, not as (new int)*i

