
template<class T1 = int, class T2> class B;

// error

// U can be neither deduced from the parameter-type-list nor speciﬁed
template<class... T, class U> void g() { }

