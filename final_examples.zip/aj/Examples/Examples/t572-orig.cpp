
template <class T> int f(T[5]);
int I = f<int>(0);
int j = f<void>(0);

// invalid array

