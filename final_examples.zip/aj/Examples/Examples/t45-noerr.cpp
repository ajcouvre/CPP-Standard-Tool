
struct A { };
namespace N {
struct A {

};

}

void g() { }
template <class T> operator T();

§ 3.4.5

58

c(cid:13) ISO/IEC

N4296

int main() {

N::A a;
a.operator A();

}

// calls N::A::operator N::A

1

