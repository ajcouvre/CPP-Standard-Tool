
struct A {};
struct B : public A {} b;
int f(A&);
int f(B&);
int i = f(b);

// calls f(B&), an exact match, rather than
// f(A&), a conversion

