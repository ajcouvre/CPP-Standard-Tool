
void g(double);
void h();

template<class T> class Z {
public:

void f() {

g(1);
h++;

}
};

void g(int);

// calls g(double)
// ill-formed: cannot increment function;
// this could be diagnosed either here or
// at the point of instantiation

// not in scope at the point of the template
// deﬁnition, not considered for the call g(1)

