
§ 14.8.2.5

408

c(cid:13) ISO/IEC

N4296

template<class T, T i> void f(double a[10][i]);
int v[10][20];
f(v);


15

