int main()
{
struct X {

enum direction { left=’l’, right=’r’ };
int f(int i) { return i==left ? 0 : i==right ? 1 : 2; }

void g(X* p) {
direction d;
int i;
i = p->f(left);
i = p->f(X::right);
i = p->f(p->left);
// ...

}

// error: direction not in scope

// error: left not in scope
// OK
// OK


return 0;
}
