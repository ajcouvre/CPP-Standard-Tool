
class buffer {
private:

char* p;
int size;

protected:

public:

};

buffer(int s, char* store) { size = s; p = store; }

buffer(int s) { p = new char[size = s]; }

