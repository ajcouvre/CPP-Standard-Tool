than char, signed char, or unsigned char can be declared as:

alignas(T) alignas(A) T buffer[N];

§ 7.6.2

187

c(cid:13) ISO/IEC

N4296

Specifying alignas(T) ensures that the ﬁnal requested alignment will not be weaker than alignof(T), and
