
struct S2 { void f(int i); };
void S2::f(int i) {

// OK

[&, i]{ };
[&, &i]{ };
[i, i]{ };


}

