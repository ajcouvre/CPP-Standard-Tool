
int g();
struct X {

static int g();

};

§ 9.4

236

c(cid:13) ISO/IEC

struct Y : X {
static int i;

};
int Y::i = g();

// equivalent to Y::g();

N4296

4

