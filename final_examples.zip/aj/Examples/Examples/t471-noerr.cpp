
template<class T> class Array {

T* v;
int sz;

public:

};

explicit Array(int);
T& operator[](int);
T& elem(int i) { return v[i]; }

2 The preﬁx template <class T> speciﬁes that a template is being declared and that a type-name T will be
used in the declaration. In other words, Array is a parameterized type with T as its parameter. — end
example ]

3 When a member function, a member class, a member enumeration, a static data member or a member
template of a class template is deﬁned outside of the class template deﬁnition, the member deﬁnition is
deﬁned as a template deﬁnition in which the template-parameters are those of the class template. The
names of the template parameters used in the deﬁnition of the member may be diﬀerent from the template
parameter names used in the class template deﬁnition. The template argument list following the class
template name in the member deﬁnition shall name the parameters in the same order as the one used in the
template parameter list of the member. Each template parameter pack shall be expanded with an ellipsis

template<class T1, class T2> struct A {

void f1();
void f2();

};

};

template<class T2, class T1> void A<T2,T1>::f1() { }
template<class T2, class T1> void A<T1,T2>::f2() { }

// OK

template<class ... Types> struct B {

void f3();
void f4();

template<class ... Types> void B<Types ...>::f3() { }
template<class ... Types> void B<Types>::f4() { }

// OK

4

