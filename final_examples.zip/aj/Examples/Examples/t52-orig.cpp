
class T { };
struct B {

~B();

};

void h() {

B b;
new (&b) T;

}

// undeﬁned behavior at block exit

