
class B { };
template <class T> class C {
protected:

typedef T TT;

};

template <class U, class V = typename U::TT>
class D : public U { };

// access error, C::TT is protected

D <C<B> >* d;
