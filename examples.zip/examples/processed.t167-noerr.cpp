int main()
{
namespace Outer {

int i;
namespace Inner {

void f() { i++; }
int i;
void g() { i++; }

}

}

// Outer::i

// Inner::i


return 0;
}
