
duration<int, milli> ms(3);
duration<int, micro> us = ms;
duration<int, milli> ms2 = us;

// OK
// error

