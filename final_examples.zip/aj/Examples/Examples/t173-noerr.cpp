
// Assume f and g have not yet been declared.
void h(int);
template <class T> void f2(T);
namespace A {

class X {

friend void f(X);
class Y {

friend void g();
friend void h(int);

// A::f(X) is a friend

// A::g is a friend
// A::h is a friend
// ::h not considered
// ::f2<>(int) is a friend

friend void f2<>(int);

};

};

// A::f, A::g and A::h are not visible here
X x;
void g() { f(x); }
void f(X) { /* ...
void h(int) { /* ...
// A::f, A::g and A::h are visible here and known to be friends

// deﬁnition of A::g
// deﬁnition of A::f
// deﬁnition of A::h

*/ }

*/}

}

using A::x;

void h() {
A::f(x);
A::X::f(x);
A::X::Y::g();

}


