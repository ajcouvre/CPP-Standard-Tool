
template<class ...> struct Tuple { };
// #1
template<class ... Types> void g(Tuple<Types ...>);
// #2
template<class T1, class ... Types> void g(Tuple<T1, Types ...>);
template<class T1, class ... Types> void g(Tuple<T1, Types& ...>); // #3

g(Tuple<>());
g(Tuple<int, float>());
g(Tuple<int, float&>());
g(Tuple<int>());

// calls #1
// calls #2
// calls #3
// calls #3

