// Given:
struct P final { };
union U1 { };
union U2 final { };

§ 20.10.4.3

614

c(cid:13) ISO/IEC

N4296

// the following assertions hold:
static_assert(!is_final<int>::value, "Error!");
static_assert( is_final<P>::value, "Error!");
static_assert(!is_final<U1>::value, "Error!");
static_assert( is_final<U2>::value, "Error!");

