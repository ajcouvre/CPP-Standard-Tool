
2 A function template can be overloaded with other function templates and with non-template functions (8.3.5).
A non-template function is not related to a function template (i.e., it is never considered to be a specializa-
tion), even if it has the same name and type as a potentially generated function template specialization.140
14.5.6.1 Function template overloading
[temp.over.link]
It is possible to overload function templates so that two diﬀerent function template specializations have the

1

// ﬁle1.c
template<class T>

void f(T*);

void g(int* p) {

}

// ﬁle2.c
template<class T>

void f(T);

void h(int* p) {

}

f(p); // calls f<int>(int*)

f(p); // calls f<int*>(int*)

