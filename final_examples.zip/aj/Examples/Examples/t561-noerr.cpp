
template<class T> void f(T* p) {

static T s;

};

}

f(&a);
f(&b);

void g(int a, char* b) {

// calls f<int>(int*)
// calls f<char*>(char**)

Here f<int>(int*) has a static variable s of type int and f<char*>(char**) has a static variable s of
