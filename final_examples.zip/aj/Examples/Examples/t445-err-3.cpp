
template<class T1 = int, class T2> class B;


// U can be neither deduced from the parameter-type-list nor speciﬁed
// error
template<class... T, class U> void g() { }

