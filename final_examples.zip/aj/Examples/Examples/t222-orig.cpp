
1

2

void point(int = 3, int = 4);

declares a function that can be called with zero, one, or two arguments of type int. It can be called in any
of these ways:
point(1,2);

point(1);

point();

