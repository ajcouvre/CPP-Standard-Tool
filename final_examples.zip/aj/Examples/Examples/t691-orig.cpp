
3

j

§ 26.6.6.1

995

c(cid:13) ISO/IEC

= 3

start
length = {2, 4, 3}
stride = {19, 4, 1}

yields the sequence of one-dimensional indices

k = 3 + (0, 1) × 19 + (0, 1, 2, 3) × 4 + (0, 1, 2) × 1

which are ordered as shown in the following table:

N4296

(i0,

i1,
(0,
(0,
(0,
(0,
(0,
(0,
(0,
(0,
(0,
(0,
(0,
(0,
(1,
(1,
. . .
(1,

i2,
0,
0,
0,
1,
1,
1,
2,
2,
2,
3,
3,
3,
0,
0,

3,

k) =
3),
0,
4),
1,
2,
5),
7),
0,
8),
1,
2,
9),
11),
0,
1,
12),
13),
2,
15),
0,
16),
1,
2,
17),
22),
0,
1,
23),

2,

36)

