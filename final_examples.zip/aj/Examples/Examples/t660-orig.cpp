
duration<long, ratio<60>> d0;
duration<long long, milli> d1;
duration<double, ratio<1, 30>>

// holds a count of minutes using a long
// holds a count of milliseconds using a long long
30 of a second

d2; // holds a count with a tick period of 1

// (30 Hz) using a double

