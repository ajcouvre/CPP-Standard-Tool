
int work1(int value);
int work2(int value);
int work(int value) {

auto handle = std::async([=]{ return work2(value); });
int tmp = work1(value);
return tmp + handle.get();

// #1

}

[ Note: Line #1 might not result in concurrency because the async call uses the default policy, which may
use launch::deferred, in which case the lambda might not be invoked until the get() call; in that case,
