
class B {
public:
int m;

};

class S: private B {

friend class N;

};

void f() {

B* p = this;

// OK because class S satisﬁes the fourth condition
// above: B is a base class of N accessible in f() because
// B is an accessible base class of S and S is an accessible
// base class of N.

class N: private S {

}
};

5

