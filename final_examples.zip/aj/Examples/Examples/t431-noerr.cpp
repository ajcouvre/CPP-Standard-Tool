
struct A {

operator short();

} a;
int f(int);
int f(float);
int i = f(a);

// calls f(int), because short → int is
// better than short → float.

