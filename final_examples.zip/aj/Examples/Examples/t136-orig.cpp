
struct S;
typedef struct S S;
int main() {

struct S* p;

// OK

}
struct S { };
