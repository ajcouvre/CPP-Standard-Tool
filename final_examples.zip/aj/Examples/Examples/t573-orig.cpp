
(8.3)

—

template <class T> int f(typename T::B*);
int i = f<int>(0);

(8.4)

—

(8.4.1)

(8.4.2)

(8.4.3)

