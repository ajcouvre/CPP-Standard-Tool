
class X { /* ... */ };

§ 10.1

244

BaseDerived1Derived2c(cid:13) ISO/IEC

N4296

class Y : public X, public X { /* ... */ };
class L { public: int next; /* ... */ };
class A : public L { /* ... */ };
class B : public L { /* ... */ };
class C : public A, public B { void f(); /* ... */ };
class D : public A, public L { void f(); /* ... */ };

// ill-formed

// well-formed
// well-formed

