
transform(a.begin(), a.end(), a.begin(), negate<double>());

