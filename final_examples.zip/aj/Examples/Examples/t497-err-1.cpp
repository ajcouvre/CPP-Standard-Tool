
template <class T, T t> struct C {};
template <class T> struct C<T, 1>;

// error

template< int X, int (*array_ptr)[X] > class A {};
int array[5];
template< int X > class A<X,&array> { };


(8.3)

—

