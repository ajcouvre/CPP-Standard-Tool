
struct Map {

Map(std::initializer_list<std::pair<std::string,int>>);

};
Map ship = {{"Sophie",14}, {"Surprise",28}};

