int main()
{completely handle the exception itself, can be written like this:

§ 5.17

130

c(cid:13) ISO/IEC

N4296

try {

// ...

}

} catch (...) {

// catch all exceptions

// respond (partially) to exception
throw;

// pass the exception to some
// other handler

4


return 0;
}
