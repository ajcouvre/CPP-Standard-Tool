and speciﬁes error conditions that include operation_not_permitted for a thread that does not have the
privilege to perform the operation. Assume that, during the execution of this function, an errno of EPERM is
reported by a POSIX API call used by the implementation. Since POSIX speciﬁes an errno of EPERM when
“the caller does not have the privilege to perform the operation”, the implementation maps EPERM to an
