
complex z = a.operator+(b);
void* p = operator new(sizeof(int)*n);

// complex z = a+b;

