
struct C {

§ 12.6.2

281

c(cid:13) ISO/IEC

C( int ) { }
C(): C(42) { }
C( char c ) : C(42.0) { }
C( double d ) : C(’a’) { }

};

