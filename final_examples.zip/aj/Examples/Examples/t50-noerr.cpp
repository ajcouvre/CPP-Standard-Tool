
#include <cstdlib>

struct B {

virtual void f();
void mutate();
virtual ~B();

};

40) For example, before the construction of a global object of non-POD class type (12.7).

§ 3.8

70

c(cid:13) ISO/IEC

N4296

struct D1 : B { void f(); };
struct D2 : B { void f(); };

void B::mutate() {

new (this) D2;
f();
... = this;

// reuses storage — ends the lifetime of *this
// undeﬁned behavior
// OK, this points to valid memory

}

}

void g() {

void* p = std::malloc(sizeof(D1) + sizeof(D2));
B* pb = new (p) D1;
pb->mutate();
&pb;
void* q = pb;
pb->f();

// OK: pb points to valid memory
// OK: pb points to valid memory
// undeﬁned behavior, lifetime of *pb has ended

