
int x;
void f() {

static int s ;
int x;
const int N = 5;
extern int q();

struct local {

int g() { return x; }
int h() { return s; }
int k() { return ::x; }
int l() { return q(); }
int m() { return N; }
int* n() { return &N; }

};

}

// error: odr-use of automatic variable x
// OK
// OK
// OK
// OK: not an odr-use
// error: odr-use of automatic variable N

local* p = 0;

