int main()
{
template <class T> auto f(T t) { return t; } // return type deduced at instantiation time
// instantiates f<int> to deduce return type
typedef decltype(f(1)) fint_t;
template<class T> auto f(T* t) { return *t; }
void g() { int (*p)(int*) = &f; }

// instantiates both fs to determine return types,
// chooses second


return 0;
}
