int main()
{typedef struct { } *ps, S;

// S is the class name for linkage purposes


return 0;
}
