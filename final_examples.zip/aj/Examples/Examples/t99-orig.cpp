well-formed (because n is the expression of a noptr-new-declarator), but new float[5][n] is ill-formed
