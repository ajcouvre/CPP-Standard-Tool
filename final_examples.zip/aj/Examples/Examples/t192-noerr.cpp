
int x;
namespace A {

extern "C" int f();
extern "C" int g() { return 1; }
extern "C" int h();
extern "C" int x();

}

// ill-formed: same name as global-space object x

§ 7.5

184

c(cid:13) ISO/IEC

N4296

namespace B {

}

extern "C" int f();
extern "C" int g() { return 1; } // ill-formed, the function g

// A::f and B::f refer to the same function

// with C language linkage has two deﬁnitions

int A::f() { return 98; }
extern "C" int h() { return 97; }

//deﬁnition for the function f with C language linkage
// deﬁnition for the function h with C language linkage
// A::h and ::h refer to the same function

