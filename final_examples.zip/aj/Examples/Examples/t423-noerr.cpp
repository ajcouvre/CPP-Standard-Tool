
struct A {
int m1;
double m2;

};

§ 13.3.3.1.5

319

c(cid:13) ISO/IEC

void f(const A&);
f( {’a’, ’b’} );
f( {1.0} );

void g(const double &);
g({1});

