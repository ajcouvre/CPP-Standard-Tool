
3

{ };
template<class T1, class T2, int I> class A
template<class T, int I>
{ };
template<class T1, class T2, int I> class A<T1*, T2, I> { };
template<class T>
class A<int, T*, 5> { };
template<class T1, class T2, int I> class A<T1, T2*, I> { };

class A<T, T*, I>

// #1
// #2
// #3
// #4
// #5

The ﬁrst declaration declares the primary (unspecialized) class template. The second and subsequent dec-
