
N4296

template<int i> class A { /* ... */ };
template<short s> void f(A<s>);
void k1() {

// error: deduction fails for conversion from int to short
// OK

A<1> a;
f(a);
f<1>(a);

B<1> b;
g(b);

template<const short cs> class B { };
template<short s> void g(B<s>);
void k2() {

// OK: cv-qualiﬁers are ignored on template parameter types

