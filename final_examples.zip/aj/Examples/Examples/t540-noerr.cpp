
template<class T> class B { /* ... */ };
template<class T> class D : public B<T> { /* ... */ };

void f(void*);
void f(B<int>*);

void g(D<int>* p, D<char>* pp, D<double>* ppp) {

f(p);
B<char>* q = pp; // instantiation of D<char> required:

// instantiation of D<int> required: call f(B<int>*)

// convert D<char>* to B<char>*
// instantiation of D<double> required

delete ppp;

}

§ 14.7.1

381

c(cid:13) ISO/IEC

N4296

7

