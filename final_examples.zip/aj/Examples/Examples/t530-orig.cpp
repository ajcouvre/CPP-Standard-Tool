
struct A {

struct B { /* ... */ };
int a;
int Y;

};

int a;

template<class T> struct Y : T {

struct B { /* ... */ };
B b;
void f(int i) { a = i; }
Y* p;

};

// The B deﬁned in Y
// ::a
// Y<T>

Y<A> ya;

The members A::B, A::a, and A::Y of the template argument A do not aﬀect the binding of names in Y<A>.
