
template <class T> struct S {

operator int();

};

void f(int);
void f(S<int>&);
void f(S<float>);

void g(S<int>& sr) {

f(sr);

};

// instantiation of S<int> allowed but not required
// instantiation of S<float> allowed but not required

8

