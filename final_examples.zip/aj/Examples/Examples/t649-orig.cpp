
is_const<const volatile int>::value
is_const<const int*>::value
is_const<const int&>::value
is_const<int[3]>::value
is_const<const int[3]>::value

// true
// false
// false
// false
// true

5

6

