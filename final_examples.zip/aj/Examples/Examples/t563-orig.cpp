
template<class X, class Y> X f(Y);
template<class X, class Y, class ... Z> X g(Y);
void h() {

int i = f<int>(5.6);
int j = f(5.6);
f<void>(f<int, bool>);

f<void>(f<int>);

int k = g<int>(5.6);
f<void>(g<int, bool>);

}

// Y is deduced to be double
// ill-formed: X cannot be deduced
// Y for outer f deduced to be
// int (*)(bool)
// ill-formed: f<int> does not denote a
// single function template specialization
// Y is deduced to be double, Z is deduced to an empty sequence
// Y for outer f is deduced to be
// int (*)(bool), Z is deduced to an empty sequence

4

