
void f(int);
f( {’a’} );
f( {1.0} );

// OK: same conversion as char to int
// error: narrowing

(9.2)

—

