
class A {
public:

static int n;

};
int main() {

int A;
A::n = 42;
A b;

}

// OK
// ill-formed: A does not name a type

2

3

