int main()
{
struct B {

void f(char);
void g(char);
enum E { e };
union { int x; };

};

struct D : B {
using B::f;
void f(int) { f(’c’); }
void g(int) { g(’c’); }

};

// calls B::f(char)
// recursively calls D::g(int)


return 0;
}
