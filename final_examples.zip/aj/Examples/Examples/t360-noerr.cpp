
16

typedef int I;
I* p;
p->I::~I();
— end note ]

§ 12.4

277

c(cid:13) ISO/IEC

12.5 Free store

N4296

[class.free]

1 Any allocation function for a class T is a static member (even if not explicitly declared static).
2


void* operator new(std::size_t, Arena*);

class Arena;
struct B {

};
struct D1 : B {
};

Arena*
void foo(int i) {

ap;

new (ap) D1;
new D1[i];
new D1;

}

// calls B::operator new(std::size_t, Arena*)
// calls ::operator new[](std::size_t)
// ill-formed: ::operator new(std::size_t) hidden

