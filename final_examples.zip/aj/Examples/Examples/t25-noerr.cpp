
typedef int
c;
enum { i = 1 };

class X {

char

v[i];

int f() { return sizeof(c); }
char
enum { i = 2 };

c;

};

typedef char*
struct Y {

T

a;

T;

typedef long
T

b;

T;

};

typedef int I;
class D {

typedef I I;

};

// but when reevaluated is X::i
// OK: X::c

// but when reevaluated is Y::T


