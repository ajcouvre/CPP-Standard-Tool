true: "a" and false: "abb", the input sequence "a" yields val == true and err == str.eofbit;
the input sequence "abc" yields err = str.failbit, with in ending at the ’c’ element. For targets
true: "1" and false: "0", the input sequence "1" yields val == true and err == str.goodbit.
