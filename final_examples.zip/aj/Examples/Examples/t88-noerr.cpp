
class A { virtual void f(); };
class B { virtual void g(); };
class D : public virtual A, private B { };
void g() {

67) The most derived object (1.8) pointed or referred to by v can contain other B objects as base classes, but these are ignored.

§ 5.2.7

107

c(cid:13) ISO/IEC

N4296

d;
bp = (B*)&d;
ap = &d;
dr = dynamic_cast<D&>(*bp);

D
B*
A*
D&
ap = dynamic_cast<A*>(bp);
bp = dynamic_cast<B*>(ap);
ap = dynamic_cast<A*>(&d);
bp = dynamic_cast<B*>(&d);

}

// cast needed to break protection
// public derivation, no cast needed
// fails
// fails
// fails
// succeeds
// ill-formed (not a run-time check)

class E : public D, public B { };
class F : public E, public D { };
void h() {

F
A*
D*

f;
ap
dp

= &f;
= dynamic_cast<D*>(ap);

E*
E*

= (E*)ap;

ep
ep1 = dynamic_cast<E*>(ap);

}

// succeeds: ﬁnds unique A
// fails: yields 0
// f has two D subobjects
// ill-formed: cast from virtual base
// succeeds

