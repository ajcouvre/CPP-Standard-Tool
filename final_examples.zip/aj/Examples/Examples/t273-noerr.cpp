108) This ensures that two subobjects that have the same class type and that belong to the same most derived object are not
allocated at the same address (5.10).

Classes

227

c(cid:13) ISO/IEC

N4296

struct B { int i; };
struct C : B { };
struct D : C { };
struct E : D { char : 4; }; // not a standard-layout class

// standard-layout class
// standard-layout class
// standard-layout class

struct Q {};
struct S : Q { };
struct T : Q { };
struct U : S, T { };

