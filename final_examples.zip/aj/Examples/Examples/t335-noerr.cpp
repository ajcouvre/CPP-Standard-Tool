
class C;
typedef C Ct;

class X1 {
friend C;

};

class X2 {

friend Ct;
friend D;
friend class D;

// OK: class C is a friend

// OK: class C is a friend
// OK: elaborated-type-speciﬁer declares new class

template <typename T> class R {

friend T;

R<C> rc;
R<int> Ri;

// class C is a friend of R<C>
// OK: "friend int;" is ignored

§ 11.3

262

c(cid:13) ISO/IEC

