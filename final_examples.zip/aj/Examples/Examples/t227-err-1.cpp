
class A {

void f(A* p = this) { }

// error

§ 8.3.6

205

c(cid:13) ISO/IEC

