int main()
{
struct B {

virtual void f(int);
virtual void f(char);
void g(int);
void h(int);

};

struct D : B {
using B::f;
void f(int);

using B::g;
void g(char);

using B::h;
void h(int);

};

// OK: D::f(int) overrides B::f(int);

// OK

// OK: D::h(int) hides B::h(int)

void k(D* p)
{

p->f(1);
p->f(’a’);
p->g(1);
p->g(’a’);

}

// calls D::f(int)
// calls B::f(char)
// calls B::g(int)
// calls D::g(char)


return 0;
}
