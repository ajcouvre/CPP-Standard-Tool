int main()
{never deﬁnes X:

struct X;
struct X* x1;
X* x2;

// declare X as a struct type
// use X in pointer formation
// use X in pointer formation


return 0;
}
