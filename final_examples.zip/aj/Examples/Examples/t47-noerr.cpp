
namespace X {
void p() {

q();
extern void q();

}

}

void middle() {

q();

// q is a member of namespace X


void q() { /* ...

*/ }

// deﬁnition of X::q

}

void q() { /* ...

*/ }

// some other, unrelated q

