
typedef int complex;
class complex { /* ...

*/ };

// error: redeﬁnition

8

