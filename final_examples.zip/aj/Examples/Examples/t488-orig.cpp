
template<class T> class task;
template<class T> task<T>* preempt(task<T>*);

template<class T> class task {

friend void next_time();
friend void process(task<T>*);
friend task<T>* preempt<T>(task<T>*);
template<class C> friend int func(C);

friend class task<int>;
template<class P> friend class frd;

};

Here, each specialization of the task class template has the function next_time as a friend; because process
does not have explicit template-arguments, each specialization of the task class template has an appropriately
typed function process as a friend, and this friend is not a function template specialization; because the
friend preempt has an explicit template-argument T, each specialization of the task class template has the
appropriate specialization of the function template preempt as a friend; and each specialization of the task
class template has all specializations of the function template func as friends. Similarly, each specialization of
the task class template has the class template specialization task<int> as a friend, and has all specializations
