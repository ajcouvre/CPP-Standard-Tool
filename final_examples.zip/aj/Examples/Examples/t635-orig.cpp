
template <class T, class A1, class A2>
shared_ptr<T> factory(A1&& a1, A2&& a2) {

return shared_ptr<T>(new T(std::forward<A1>(a1), std::forward<A2>(a2)));

}

};

struct A {

A(int&, const double&);

void g() {

§ 20.2.4

517

template <class T, class A1>
shared_ptr<T> factory(A1&& a1) {

return shared_ptr<T>(new T(std::forward<A1>(a1)));

struct A {

A();
A(const A&); // copies from lvalues
// moves from rvalues
A(A&&);

}

};

}

5

6

7

8

9

c(cid:13) ISO/IEC

N4296

shared_ptr<A> sp1 = factory<A>(2, 1.414); // error: 2 will not bind to int&
int i = 2;
shared_ptr<A> sp2 = factory<A>(i, 1.414); // OK

}

In the ﬁrst call to factory, A1 is deduced as int, so 2 is forwarded to A’s constructor as an rvalue. In
the second call to factory, A1 is deduced as int&, so i is forwarded to A’s constructor as an lvalue.
In both cases, A2 is deduced as double, so 1.414 is forwarded to A’s constructor as an rvalue.
