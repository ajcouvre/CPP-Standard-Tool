
template<class T> struct A {

typedef int M;
struct B {

typedef void M;
struct C;

template<class T> struct A<T>::B::C : A<T> {

M m; // OK, A<T>::M

};

};

};

};

}

