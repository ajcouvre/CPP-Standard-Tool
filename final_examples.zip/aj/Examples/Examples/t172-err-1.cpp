
namespace Q {

namespace V {

void f();

}
void V::f() { /* ... */ }
void V::g() { /* ... */ }
namespace V {

void g();

// OK
// error: g() is not yet a member of V

}

}

}

namespace R {


3

