int main()
{
struct A {
int val;
A(int i) : val(i) { }
~A() { }
operator bool() { return val != 0; }

};
int i = 1;
while (A a = i) {

// ...
i = 0;

}

§ 6.5.1

140

c(cid:13) ISO/IEC

N4296

In the while-loop, the constructor and destructor are each called twice, once for the condition that succeeds

return 0;
}
