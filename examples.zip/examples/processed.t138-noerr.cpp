int main()
{
typedef int complex;
class complex { /* ...

*/ };


8


return 0;
}
