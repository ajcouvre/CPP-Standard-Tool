int main()
{
struct S;
extern S a;
extern S f();
extern void g(S);

void h() {

g(a);
f();

}

// error: S is incomplete
// error: S is incomplete


return 0;
}
