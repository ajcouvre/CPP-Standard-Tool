
class String { };
template<class T> class Array { /* ... */ };
template<class T> void sort(Array<T>& v) { /* ... */ }

void f(Array<String>& v) {

sort(v);

// use primary template
// sort(Array<T>&), T is String

}

template<> void sort<String>(Array<String>& v); // error: specialization

// after use of primary template
// OK: sort<char*> not yet used

template<> void sort<>(Array<char*>& v);
template<class T> struct A {

enum E : T;
enum class S : T;

};
template<> enum A<int>::E : int { eint };
template<> enum class A<int>::S : int { sint };
template<class T> enum A<T>::E : T { eT };
template<class T> enum class A<T>::S : T { sT };
template<> enum A<char>::E : char { echar };

// OK
// OK

// ill-formed, A<char>::E was instantiated
// when A<char> was instantiated

§ 14.7.3

388

c(cid:13) ISO/IEC

N4296

template<> enum class A<char>::S : char { schar }; // OK

