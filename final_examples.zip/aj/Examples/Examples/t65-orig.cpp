60) The precedence of operators is not directly speciﬁed, but it can be derived from the syntax.

Expressions

88

c(cid:13) ISO/IEC

N4296

struct A {

int m;

};
A&& operator+(A, A);
A&& f();

A a;
A&& ar = static_cast<A&&>(a);

8

The expressions f(), f().m, static_cast<A&&>(a), and a + a are xvalues. The expression ar is an lvalue.
