violates a constraint on increment operators, even though the parse x ++ + ++ y might yield a correct
