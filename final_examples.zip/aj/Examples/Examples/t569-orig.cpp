
template <class T, class U = double>
void f(T t = 0, U u = 0);

void g() {

f(1, ’c’);
f(1);
f();
f<int>();
f<int,char>();

}

// f<int,char>(1,’c’)
// f<int,double>(1,0)
// error: T cannot be deduced
// f<int,double>(0,0)
// f<int,char>(0,0)

