
T* p1 = new T;
T* p2 = new(nothrow) T;

// throws bad_alloc if it fails
// returns nullptr if it fails

