
struct Node {

struct Node* Next;
struct Data* Data;

};

struct Data {

struct Node* Node;
friend struct ::Glob;

friend struct Glob;
/* ... */

};

// OK: Refers to Node at global scope
// OK: Declares type Data
// at global scope and member Data

// OK: Refers to Node at global scope
// cannot introduce a qualiﬁed type (7.1.6.3)
// OK: Refers to (as yet) undeclared Glob
// at global scope.

struct Base {
struct Data;
struct ::Data*
struct Base::Data* thisData; // OK: Refers to nested Data
// OK: global Data is a friend
friend class ::Data;
// OK: nested Data is a friend
friend class Data;
// Deﬁnes nested Data
struct Data { /* ...

thatData; // OK: Refers to ::Data

// OK: Declares nested Data

};

*/ };

struct Data;
struct ::Data;
struct Base::Data;
struct Base::Datum;
struct Base::Data* pBase;

// OK: Redeclares Data at global scope
// error: cannot introduce a qualiﬁed type (7.1.6.3)
// OK: refers to nested Data

