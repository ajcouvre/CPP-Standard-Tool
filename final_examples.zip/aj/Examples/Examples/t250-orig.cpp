
int x[2][2] = { 3, 1, 4, 2 };

initializes x[0][0] to 3, x[0][1] to 1, x[1][0] to 4, and x[1][1] to 2. On the other hand,

float y[4][3] = {

{ 1 }, { 2 }, { 3 }, { 4 }

};

initializes the ﬁrst column of y (regarded as a two-dimensional array) and leaves the rest zero. — end
example ]

12 Braces can be elided in an initializer-list as follows.

If the initializer-list begins with a left brace, then
the succeeding comma-separated list of initializer-clauses initializes the members of a subaggregate; it is
erroneous for there to be more initializer-clauses than members. If, however, the initializer-list for a sub-
aggregate does not begin with a left brace, then only enough initializer-clauses from the list are taken to
initialize the members of the subaggregate; any remaining initializer-clauses are left to initialize the next

float y[4][3] = {

{ 1, 3, 5 },
{ 2, 4, 6 },
{ 3, 5, 7 },

};

is a completely-braced initialization: 1, 3, and 5 initialize the ﬁrst row of the array y[0], namely y[0][0],
y[0][1], and y[0][2]. Likewise the next two lines initialize y[1] and y[2]. The initializer ends early and
therefore y[3]s elements are initialized as if explicitly initialized with an expression of the form float(),
that is, are initialized with 0.0. In the following example, braces in the initializer-list are elided; however
the initializer-list has the same eﬀect as the completely-braced initializer-list of the above example,

float y[4][3] = {

1, 3, 5, 2, 4, 6, 3, 5, 7

};

The initializer for y begins with a left brace, but the one for y[0] does not, therefore three elements from
