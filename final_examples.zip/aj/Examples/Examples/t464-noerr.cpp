
template<const int& CRI> struct B { /* ... */ };

B<1> b2;

int c = 1;
B<c> b1;


// OK

