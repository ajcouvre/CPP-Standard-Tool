
struct C {

typedef int I;

};
typedef int I1, I2;
extern int* p;
extern int* q;
p->C::I::~I();
q->I1::~I2();

struct A {

~A();

};
typedef A AB;
int main() {

AB* p;
p->AB::~AB();

}

// I is looked up in the scope of C
// I2 is looked up in the scope of
// the postﬁx-expression

// explicitly calls the destructor for A

