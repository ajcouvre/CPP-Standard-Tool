
int a;
extern const int c = 1;
int f(int x) { return x+a; }
struct S { int a; int b; };
struct X {

int x;
static int y;
X(): x(0) { }

};
int X::y = 1;
enum { up, down };
namespace N { int d; }
namespace N1 = N;
X anX;

whereas these are just declarations:

extern int a;
extern const int c;
int f(int);
struct S;
typedef int Int;
extern X anotherX;
using N::d;

// deﬁnes a
// deﬁnes c
// deﬁnes f and deﬁnes x
// deﬁnes S, S::a, and S::b
// deﬁnes X
// deﬁnes non-static data member x
// declares static data member y
// deﬁnes a constructor of X

// deﬁnes X::y
// deﬁnes up and down
// deﬁnes N and N::d
// deﬁnes N1
// deﬁnes anX

// declares a
// declares c
// declares f
// declares S
// declares Int
// declares anotherX
// declares d

3

