
struct V { int f();
struct W { int g();
struct B : virtual V, W {

int x; };
int y; };

int f();
int g();

int x;
int y;

};
struct C : virtual V, W { };

struct D : B, C { void glorp(); };

Figure 6 — Name lookup

11

[ Note: The names declared in V and the left-hand instance of W are hidden by those in B, but the names
declared in the right-hand instance of W are not hidden at all. — end note ]

void D::glorp() {

x++;
f();
y++;
g();

// OK: B::x hides V::x
// OK: B::f() hides V::f()
// error: B::g() and C’s W::g()

§ 10.2

248

WVWBCDc(cid:13) ISO/IEC

}

