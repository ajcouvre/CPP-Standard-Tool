
10

void f(char);

§ 14.6

367

c(cid:13) ISO/IEC

N4296

template<class T> void g(T t) {
// f(char)
// dependent
// dependent
// not dependent

f(1);
f(T(1));
f(t);
dd++;

}

enum E { e };
void f(E);

double dd;
void h() {

g(e);

g(’a’);

}

// will cause one call of f(char) followed
// by two calls of f(E)
// will cause three calls of f(char)

11

