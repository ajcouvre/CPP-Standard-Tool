
struct S {

template<typename T> S(T);
S();

};

S g;

void h() {
S a(g);

}

// does not instantiate the member template to produce S::S<S>(S);
// uses the implicitly declared copy constructor

7

