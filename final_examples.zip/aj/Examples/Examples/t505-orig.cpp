
struct A { };
template<class T> struct B {

template<class R> int operator*(R&);

};

// #1

template<class T, class R> int operator*(T&, R&);

// #2

§ 14.5.6.2

361

c(cid:13) ISO/IEC

N4296

// The declaration of B::operator* is transformed into the equivalent of
// template<class R> int operator*(B<A>&, R&);

// #1a

int main() {

A a;
B<A> b;
b * a;

}

// calls #1a

