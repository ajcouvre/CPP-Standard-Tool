
struct S {

};

enum E : int {};
enum E : int {}; // error: redeclaration of enumeration

