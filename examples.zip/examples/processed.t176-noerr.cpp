int main()
{
class C {
int g();

};

class D2 : public B {

using B::f;
using B::e;
using B::x;
using C::g;

};

// OK: B is a base of D2
// OK: e is an enumerator of base B
// OK: x is a union member of base B


return 0;
}
