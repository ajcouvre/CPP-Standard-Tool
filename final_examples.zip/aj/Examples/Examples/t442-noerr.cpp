
template<double d> class X;
template<double* pd> class Y;
template<double& rd> class Z;

// OK
// OK

