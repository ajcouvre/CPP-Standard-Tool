
template<class T> struct A {

*/ };

struct B { /* ...
typedef void C;
void f();
template<class U> void g(U);

};

§ 14.6.1

369

c(cid:13) ISO/IEC

N4296

template<class B> void A<B>::f() {

// A’s B, not the template parameter

template<class B> template<class C> void A<B>::g(C) {

// A’s B, not the template parameter
// the template parameter C, not A’s C

B b;

B b;
C c;

}

}

8

