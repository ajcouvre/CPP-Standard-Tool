int main()
{
typedef int MILES, *KLICKSP;

the constructions
MILES distance;
extern KLICKSP metricp;

are all correct declarations; the type of distance is int and that of metricp is “pointer to int.” — end
example ]

2 A typedef-name can also be introduced by an alias-declaration. The identiﬁer following the using keyword
becomes a typedef-name and the optional attribute-speciﬁer-seq following the identiﬁer appertains to that
typedef-name. It has the same semantics as if it were introduced by the typedef speciﬁer. In particular, it

using handler_t = void (*)(int);
extern handler_t ignore;
extern void (*ignore)(int);
using cell = pair<void*, cell*>;

// redeclare ignore
// ill-formed

3


return 0;
}
