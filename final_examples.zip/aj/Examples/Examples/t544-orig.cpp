
template<class T> void f(T x, T y = ydef(T()), T z = zdef(T()));

class

A { };

A zdef(A);

void g(A a, A b, A c) {

// no default argument instantiation
// default argument z = zdef(T()) instantiated
// ill-formed; ydef is not declared

f(a, b, c);
f(a, b);
f(a);

}

