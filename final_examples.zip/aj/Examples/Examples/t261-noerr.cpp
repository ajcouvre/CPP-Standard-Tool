
int a = {1};
std::complex<double> z{1,2};
new std::vector<std::string>{"once", "upon", "a", "time"}; // 4 string elements
f( {"Nicholas","Annemarie"} ); // pass list of two elements
// return list of one element
return { "Norah" };
// initialization to zero / null pointer
int* e {};
// explicitly construct a double
x = double{1};
std::map<std::string,int> anim = { {"bear",4}, {"cassowary",2}, {"tiger",7} };

