
struct {
char a;
int b:5,
c:11,
:0,
d:8;
struct {int ee:8;} e;

}

N4296

contains four separate memory locations: The ﬁeld a and bit-ﬁelds d and e.ee are each separate memory
locations, and can be modiﬁed concurrently without interfering with each other. The bit-ﬁelds b and c
together constitute the fourth memory location. The bit-ﬁelds b and c cannot be concurrently modiﬁed, but
