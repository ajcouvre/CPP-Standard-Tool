
—
—
—

(8.5)

(8.6)

(8.7)

template <class T> int f(int T::*);
int i = f<int>(0);

