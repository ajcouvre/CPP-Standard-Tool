
12

namespace N {

template<class T> class List {
public:

T* get();

};

}

template<class K, class V> class Map {
public:

N::List<V> lt;

§ 14.7.1

382

c(cid:13) ISO/IEC

V get(K);

};

N4296

void g(Map<const char*,int>& m) {

int i = m.get("Nicholas");

}

13

a call of lt.get() from Map<const char*,int>::get() would place List<int>::get() in the namespace
