
struct S2 { void f(int i); };
void S2::f(int i) {

// OK
// error: i preceded by & when & is the default

[&, i]{ };
[&, &i]{ };
[=, this]{ }; // error: this when = is the default
[i, i]{ };

// error: i repeated

}

