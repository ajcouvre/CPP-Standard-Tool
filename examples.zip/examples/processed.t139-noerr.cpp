int main()
{
struct S {

S();
~S();

};

typedef struct S T;

S a = T();
struct T * p;

§ 7.1.3

// OK

153

c(cid:13) ISO/IEC

N4296

9


return 0;
}
