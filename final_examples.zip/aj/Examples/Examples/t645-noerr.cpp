
3

if(shared_ptr<X> px = dynamic_pointer_cast<X>(py)) {

// do something with px

}

