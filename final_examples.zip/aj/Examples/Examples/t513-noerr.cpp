
// no B declared here

class X;

template<class T> class Y {

class Z;

// forward declaration of member class

void f() {

X* a1;
T* a2;
Y* a3;
Z* a4;
typedef typename T::A TA;
TA* a5;
typename T::A* a6;
T::A* a7;

B* a8;

§ 14.6

// declare pointer to X
// declare pointer to T
// declare pointer to Y<T>
// declare pointer to Z

// declare pointer to T’s A
// declare pointer to T’s A
// T::A is not a type name:
// multiply T::A by a7; ill-formed,
// no visible declaration of a7
// B is not a type name:
// multiply B by a8; ill-formed,
// no visible declarations of B and a8

364

c(cid:13) ISO/IEC

}
};

