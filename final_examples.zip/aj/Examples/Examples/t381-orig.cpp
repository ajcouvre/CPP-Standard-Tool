
struct X {
X(int);
X(const X&, int = 1);

};
X a(1);
X b(a, 0);
X c = b;

// calls X(int);
// calls X(const X&, int);
// calls X(const X&, int);

