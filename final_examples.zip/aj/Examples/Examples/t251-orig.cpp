
struct A {

int i;
operator int();

};
struct B {
A a1, a2;
int z;

};
A a;
B b = { 4, a, a };

Braces are elided around the initializer-clause for b.a1.i. b.a1.i is initialized with 4, b.a2 is initialized
