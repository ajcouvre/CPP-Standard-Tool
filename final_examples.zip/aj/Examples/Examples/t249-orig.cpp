
struct S { } s;
struct A {

S s1;
int i1;

§ 8.5.1

215

c(cid:13) ISO/IEC

S s2;
int i2;
S s3;
int i3;

} a = {
{ },
0,
s,
0
};

// Required initialization

// Required initialization

// Initialization not required for A::s3 because A::i3 is also not initialized

N4296

10

