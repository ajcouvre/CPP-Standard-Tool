
template<class... T> struct X : T... { };
template<class... T> void f(T... values) {

X<T...> x(values...);

}

template void f<>(); // OK: X<> has no base classes

// x is a variable of type X<> that is value-initialized

