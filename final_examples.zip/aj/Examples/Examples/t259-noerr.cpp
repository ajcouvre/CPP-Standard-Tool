
(5.2)

—

(5.2.1)

(5.2.1.1)

(5.2.1.2)

struct A { };
struct B : A { } b;
extern B f();
const A& rca2 = f();
A&& rra = f();
struct X {

operator B();
operator int&();

// bound to the A subobject of the B rvalue.
// same as above

} x;
const A& r = x;
int i2 = 42;
int&& rri = static_cast<int&&>(i2); // bound directly to i2
B&& rrb = x;
