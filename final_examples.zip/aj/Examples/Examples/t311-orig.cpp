
struct A {

virtual void f();

};
struct B : virtual A {

virtual void f();

};
struct C : B , virtual A {

using A::f;

};

void foo() {

C c;
c.f();
c.C::f();

}

// calls B::f, the ﬁnal overrider
// calls A::f because of the using-declaration

