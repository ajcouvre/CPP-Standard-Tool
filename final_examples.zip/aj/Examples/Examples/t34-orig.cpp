
namespace NS {
class T { };
void f(T);
void g(T, int);

}
NS::T parm;
void g(NS::T, float);

§ 3.4.2

50

c(cid:13) ISO/IEC

N4296

int main() {

f(parm);
extern void g(NS::T, float);
g(parm, 1);

// OK: calls NS::f

// OK: calls g(NS::T, float)

}

