
§ 14.6

366

c(cid:13) ISO/IEC

N4296

int j;
template<class T> class X {

void f(T t, int i, char* p) {

t = i;

p = i;

p = j;

}
void g(T t) {

+;

}
};

// diagnosed if X::f is instantiated
// may be diagnosed even if X::f is
// not instantiated
// may be diagnosed even if X::f is
// not instantiated

// may be diagnosed even if X::g is
// not instantiated

template<class... T> struct A {
void operator++(int, T... t);

};
template<class... T> union X : T... { };
template<class... T> struct A : T...,



T... { };// error: duplicate base class

