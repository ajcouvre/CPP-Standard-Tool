
template<class T> class stream;
template<> class stream<char> { /* ... */ };
template<class T> class Array { /* ... */ };
template<class T> void sort(Array<T>& v) { /* ... */ }

template<> void sort<char*>(Array<char*>&) ;

Given these declarations, stream<char> will be used as the deﬁnition of streams of chars; other streams will
be handled by class template specializations instantiated from the class template. Similarly, sort<char*>
will be used as the sort function for arguments of type Array<char*>; other Array types will be sorted by
