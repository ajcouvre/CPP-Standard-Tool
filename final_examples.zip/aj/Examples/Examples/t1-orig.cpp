D, derived from B (Clause 10), the dynamic type of the expression *p is “D.” References (8.3.2) are treated
