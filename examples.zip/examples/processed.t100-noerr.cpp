int main()
{
void mergeable(int x) {

// These allocations are safe for merging:
std::unique_ptr<char[]> a{new (std::nothrow) char[8]};
std::unique_ptr<char[]> b{new (std::nothrow) char[8]};
std::unique_ptr<char[]> c{new (std::nothrow) char[x]};

g(a.get(), b.get(), c.get());

}

void unmergeable(int x) {

std::unique_ptr<char[]> a{new char[8]};
try {

// Merging this allocation would change its catch handler.
std::unique_ptr<char[]> b{new char[x]};

} catch (const std::bad_alloc& e) {

std::cerr << "Allocation failed: " << e.what() << std::endl;
throw;

}

}


return 0;
}
