
6

template <class T> void f(int i) {

T::x * i;

// T::x must not be a type

}

struct Foo {

typedef int x;

};

struct Bar {

static int const x = 5;

};

§ 14.6

365

c(cid:13) ISO/IEC

int main() {
f<Bar>(1);
f<Foo>(1);

}

