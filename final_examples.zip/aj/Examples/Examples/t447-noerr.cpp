
§ 14.1

336

c(cid:13) ISO/IEC

N4296

template<int i = 3 > 4 >
class X { /* ... */ };


template<int i = (3 > 4) >
class Y { /* ... */ };

// OK

