
struct X {

§ 9.3

233

c(cid:13) ISO/IEC

typedef int T;
static T count;
void f(T);

};
void X::f(T t = count) { }

N4296

The member function f of class X is deﬁned in global scope; the notation X::f speciﬁes that the function f
is a member of class X and in the scope of class X. In the function deﬁnition, the parameter type T refers to
the typedef member T declared in class X and the default argument count refers to the static data member
