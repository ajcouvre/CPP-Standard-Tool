int main()
{
namespace A {

int i;

}

namespace A1 {
using A::i;
using A::i;

}

// OK: double declaration

void f() {

using A::i;
using A::i;

}

// error: double declaration

struct B {

int i;

};

struct X : B {
using B::i;
using B::i;

};


return 0;
}
