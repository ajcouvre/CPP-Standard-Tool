
template<class ... Types> void f(Types& ...);
template<class T1, class ... Types> void g(T1, Types ...);
template<class T1, class ... Types> void g1(Types ..., T1);

§ 14.8.2.1

399

c(cid:13) ISO/IEC

N4296

void h(int x, float& y) {

const int z = x;
f(x, y, z);
g(x, y, z);
g1(x, y, z);
g1<int, int, int>(x, y, z); // OK, no deduction occurs

// Types is deduced to int, float, const int
// T1 is deduced to int; Types is deduced to float, int
// error: Types is not deduced

2

(2.1)

(2.2)

(2.3)

3

}

