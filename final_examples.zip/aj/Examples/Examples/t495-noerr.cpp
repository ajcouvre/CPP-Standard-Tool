
namespace N {

template<class T1, class T2> class A { };

// primary template

}

}

using N::A;

// refers to the primary template

namespace N {

template<class T> class A<T, T*> { }; // partial specialization

A<int,int*> a;

