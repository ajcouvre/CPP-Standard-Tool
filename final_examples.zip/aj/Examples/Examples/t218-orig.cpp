
9

int fseek(FILE*, long, int);

