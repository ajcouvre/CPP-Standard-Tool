
struct s { int a; };

void g(int s) {

struct s* p = new struct s;
p->a = s;

// global s
// parameter s

4

