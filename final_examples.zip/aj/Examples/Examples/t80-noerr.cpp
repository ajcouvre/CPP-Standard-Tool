
void f2() {
int i = 1;
// ill-formed
void g1(int = ([i]{ return i; })());
// ill-formed
void g2(int = ([i]{ return 0; })());
// ill-formed
void g3(int = ([=]{ return i; })());
// OK
void g4(int = ([=]{ return 0; })());
void g5(int = ([]{ return sizeof i; })()); // OK

}

