Array<T> :: operator [] () will be determined by the Array to which the subscripting operation is applied.

Array<int> v1(20);
Array<dcomplex> v2(30);

v1[3] = 7;
v2[3] = dcomplex(7,8);

// Array<int>::operator[]()
// Array<dcomplex>::operator[]()

