
template<class T> void f(void(*)(T,int));
template<class T> void foo(T,int);
void g(int,int);
void g(char,int);

void h(int,int,int);
void h(char,int);
int m() {
f(&g);
f(&h);
f(&foo);

// OK: void h(char,int) is a unique match

}

}

}

}

