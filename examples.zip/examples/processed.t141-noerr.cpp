int main()
{constexpr void square(int &x); // OK: declaration
// OK: deﬁnition
constexpr int bufsz = 1024;
constexpr struct pixel {

int x;
int y;
constexpr pixel(int);

};
constexpr pixel::pixel(int a)

: x(a), y(x)
{ square(x); }

constexpr pixel small(2);

// OK: declaration

// OK: deﬁnition

// not constant (5.20) so constexpr not satisﬁed

constexpr void square(int &x) { // OK: deﬁnition

x *= x;

}
constexpr pixel large(4);
int next(constexpr int x) {

return x + 1;

}
extern constexpr int memsz;

// OK: square deﬁned



return 0;
}
