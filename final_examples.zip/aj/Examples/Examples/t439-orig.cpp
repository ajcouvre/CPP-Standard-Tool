
template<class T>

constexpr T pi = T(3.1415926535897932385L);

template<class T>
T circular_area(T r) {
return pi<T> * r * r;

}
struct matrix_constants {

template<class T>
using pauli = hermitian_matrix<T, 2>;
template<class T>
constexpr pauli<T> sigma1 = { { 0, 1 }, { 1, 0 } };
template<class T>
constexpr pauli<T> sigma2 = { { 0, -1i }, { 1i, 0 } };
template<class T>
constexpr pauli<T> sigma3 = { { 1, 0 }, { 0, -1 } };

};

