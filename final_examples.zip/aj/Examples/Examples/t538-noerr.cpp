
template<class T> class X {

static T s;

};
template<class T> T X<T>::s = 0;
X<int> aa;
X<char*> bb;

Implicit instantiation

X<int> has a static member s of type int and X<char*> has a static member s of type char*. — end
example ]
14.7.1

[temp.inst]
1 Unless a class template specialization has been explicitly instantiated (14.7.2) or explicitly specialized (14.7.3),
the class template specialization is implicitly instantiated when the specialization is referenced in a context
that requires a completely-deﬁned object type or when the completeness of the class type aﬀects the seman-
tics of the program. [ Note: Within a template declaration, a local class or enumeration and the members
of a local class are never considered to be entities that can be separately instantiated (this includes their
default arguments, exception-speciﬁcations, and non-static data member initializers, if any). As a result, the
dependent names are looked up, the semantic constraints are checked, and any templates used are instanti-
ated as part of the instantiation of the entity within which the local class or enumeration is declared. — end
note ] The implicit instantiation of a class template specialization causes the implicit instantiation of the
declarations, but not of the deﬁnitions, default arguments, or exception-speciﬁcations of the class member
functions, member classes, scoped member enumerations, static data members and member templates; and
it causes the implicit instantiation of the deﬁnitions of unscoped member enumerations and member anony-
mous unions. However, for the purpose of determining whether an instantiated redeclaration of a member
is valid according to 9.2, a declaration that corresponds to a deﬁnition in the template is considered to be a

template<class T, class U>
struct Outer {

template<class X, class Y> struct Inner;
template<class Y> struct Inner<T, Y>;
template<class Y> struct Inner<T, Y> { };
template<class Y> struct Inner<U, Y> { };

};

// #1a
// #1b; OK: valid redeclaration of #1a
// #2

Outer<int, int> outer;


Outer<int, int>::Inner<int, Y> is redeclared at #1b. (It is not deﬁned but noted as being associated
with a deﬁnition in Outer<T, U>.) #2 is also a redeclaration of #1a.
It is noted as associated with a
