
class A {

class B { };
friend class X;

};

struct X : A::B {

A::B mx;

// OK: A::B accessible to friend
// OK: A::B accessible to member of friend

§ 11.3

261

c(cid:13) ISO/IEC

N4296

class Y {
A::B my;

};

};

// OK: A::B accessible to nested member of friend

