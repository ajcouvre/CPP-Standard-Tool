
template<class T> void f(T) { /* ... */ }
template<class T> inline T g(T) { /* ... */ }
template<> inline void f<>(int) { /* ... */ }
template<> int g<>(int) { /* ... */ }

// OK: inline
// OK: not inline

