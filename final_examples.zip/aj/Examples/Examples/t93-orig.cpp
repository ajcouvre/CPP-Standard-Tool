
typedef int *A[3];
typedef const int *const CA[3]; // array of 3 const pointer to const int

// array of 3 pointer to int

CA &&r = A{}; // ok, reference binds to temporary array object after qualiﬁcation conversion to type CA
A &&r1 = const_cast<A>(CA{});
A &&r2 = const_cast<A&&>(CA{}); // ok

// error: temporary array decayed to pointer

