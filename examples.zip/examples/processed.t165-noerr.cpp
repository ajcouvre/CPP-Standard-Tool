int main()
{
enum direction { left=’l’, right=’r’ };

void g()

{

direction d;
d = left;

// OK
// OK

96) This set of values is used to deﬁne promotion and conversion semantics for the enumeration type. It does not preclude an
expression of enumeration type from having a value that falls outside this range.

§ 7.2

168

}

};


return 0;
}
