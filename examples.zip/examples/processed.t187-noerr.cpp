int main()
{

For another example,

namespace A {

int i;

}
namespace B {

int i;
int j;
namespace C {

namespace D {

using namespace A;

§ 7.3.4

180

c(cid:13) ISO/IEC

N4296

int j;
int k;
int a = i;

}
using namespace D;
int k = 89;
int l = k;
int m = i;
int n = j;

// B::i hides A::i

// no problem yet
// ambiguous: C::k or D::k
// B::i hides A::i
// D::j hides B::j

}

}

5

6


return 0;
}
