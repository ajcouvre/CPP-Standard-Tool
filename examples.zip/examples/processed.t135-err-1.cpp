int main()
{
struct S {

typedef struct A { } A;
typedef struct B B;
typedef A A;

};

// OK
// OK
// error


return 0;
}
