is ill-formed because no object is supplied for the non-static member X::a used as an initializer.

int b;
class X {
int a;
int mem1(int i = a);

int mem2(int i = b);
static int b;

};

// error: non-static member a
// used as default argument
// OK; use X::b

The declaration of X::mem2() is meaningful, however, since no object is needed to access the static member
