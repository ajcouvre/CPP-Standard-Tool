
int f(int);
class C {
int i;
double d;

public:

C(int, double);

C::C(int ii, double id)
try : i(f(ii)), d(id) {

// constructor statements

}
catch (...) {

};

}

}

and

};

§ 15.1

415

// handles exceptions thrown from the ctor-initializer
// and from the constructor statements

