
auto f()->int(*)[4]; // function returning a pointer to array[4] of int

// not function returning array[4] of pointer to int

