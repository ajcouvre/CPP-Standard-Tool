
typedef const int cInt;

int f (int);
int f (const int);
int f (int) { /* ...
int f (cInt) { /* ...

*/ }
*/ }

// redeclaration of f(int)
// deﬁnition of f(int)
// error: redeﬁnition of f(int)

