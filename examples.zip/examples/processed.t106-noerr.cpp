int main()
{
struct B {
int f();

};
struct L : B { };
struct R : B { };

§ 5.10

127

c(cid:13) ISO/IEC

N4296

struct D : L, R { };

int (B::*pb)() = &B::f;
int (L::*pl)() = pb;
int (R::*pr)() = pb;
int (D::*pdl)() = pl;
int (D::*pdr)() = pr;
bool x = (pdl == pdr);
bool y = (pb == pl);


return 0;
}
