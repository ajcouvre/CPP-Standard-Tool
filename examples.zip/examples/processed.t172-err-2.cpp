int main()
{
namespace Q {

namespace V {

void f();

}
void V::f() { /* ... */ }
void V::g() { /* ... */ }
namespace V {

void g();

// OK

}

}

}

namespace R {

void Q::V::g() { /* ... */ } // error: R doesn*��t enclose Q

3


return 0;
}
