int main()
{
8

9

int main() {

L"A" "B" "C"_x; // OK: same as L"ABC"_x

§ 2.13.8

32

c(cid:13) ISO/IEC


return 0;
}
