on line //1 above, if B::operator delete() had been private, the delete expression would have been
