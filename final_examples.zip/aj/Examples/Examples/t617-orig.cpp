
struct A {

A(int = (A(5), 0)) noexcept;
A(const A&) throw();
A(A&&) throw();
~A() throw(X);

};
struct B {

B() throw();
B(const B&) = default; // exception speciﬁcation contains no types
B(B&&, int = (throw Y(), 0)) noexcept;
~B() throw(Y);

};
int n = 7;
struct D : public A, public B {

int * p = new (std::nothrow) int[n];
// exception speciﬁcation of D::D() contains X and std::bad_array_new_length
// exception speciﬁcation of D::D(const D&) contains no types
// exception speciﬁcation of D::D(D&&) contains Y
// exception speciﬁcation of D::~D() contains X and Y

};

Furthermore, if A::~A() or B::~B() were virtual, D::~D() would not be as restrictive as that of A::~A,
and the program would be ill-formed since a function that overrides a virtual function from a base class shall
