
namespace N {

struct S { };
void f(S);

}

void g() {
N::S s;
f(s);
(f)(s);

}

