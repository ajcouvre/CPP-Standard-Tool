int main()
{
complex<double> z;
z = { 1,2 };
z += { 1, 2 };
int a, b;
a = b = { 1 };
a = { 1 } = b;


return 0;
}
