int main()
{
constexpr int f(bool b)

{ return b ? throw 0 : 0; }

constexpr int f() { return f(true); }

struct B {

constexpr B(int x) : i(0) { }
int i;

};

// OK
// ill-formed, no diagnostic required

// x is unused

int global;

struct D : B {

constexpr D() : B(global) { }

};

// ill-formed, no diagnostic required
// lvalue-to-rvalue conversion on non-constant global

6


return 0;
}
