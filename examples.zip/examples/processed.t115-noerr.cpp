int main()
{
while (--x >= 0)

int i;

can be equivalently rewritten as

while (--x >= 0) {

int i;

}


return 0;
}
