
struct A {

template <class T> operator T*();

};
template <class T> A::operator T*(){ return 0; }
template <> A::operator char*(){ return 0; }
template A::operator void*();

// specialization
// explicit instantiation

int main() {

A a;
int* ip;
ip = a.operator int*();

}

§ 14.5.2

// explicit call to template operator
// A::operator int*()

349

c(cid:13) ISO/IEC

N4296

