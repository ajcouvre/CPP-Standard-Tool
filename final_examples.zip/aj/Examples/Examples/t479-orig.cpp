
template <class T> struct AA {

template <class C> virtual void g(C);
virtual void f();

// error
// OK

