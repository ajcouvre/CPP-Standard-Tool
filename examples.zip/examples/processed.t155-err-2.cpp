int main()
{
int i;
int&& f();
x3a = i;
auto
decltype(auto) x3d = i;
auto
x4a = (i);
decltype(auto) x4d = (i);
auto
x5a = f();
decltype(auto) x5d = f();
auto
auto
*x7a = &i;
decltype(auto)*x7d = &i;

// decltype(x3a) is int
// decltype(x3d) is int
// decltype(x4a) is int
// decltype(x4d) is int&
// decltype(x5a) is int
// decltype(x5d) is int&&

x6a = { 1, 2 }; // decltype(x6a) is std::initializer_list<int>

// decltype(x7a) is int*
// error, declared type is not plain decltype(auto)

8


return 0;
}
