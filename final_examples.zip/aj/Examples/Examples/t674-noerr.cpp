After the declaration of an uninitialized pointer x (as with int* x;), x must always be assumed to have a
