int main()
{
const auto &i = expr;

The type of i is the deduced type of the parameter u in the call f(expr) of the following invented function
template:

template <class U> void f(const U& u);


return 0;
}
