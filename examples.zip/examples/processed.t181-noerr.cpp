int main()
{
namespace A {
void f(int);

}

using A::f;

namespace A {

void f(char);

}

}

void foo() {

f(’a’);

void bar() {
using A::f;

f(’a’);

}

// f is a synonym for A::f;
// that is, for A::f(int).

// calls f(int),
// even though f(char) exists.

// f is a synonym for A::f;
// that is, for A::f(int) and A::f(char).
// calls f(char)

12


return 0;
}
