
template<class T> class A {

// primary template

};
template<class T> class A<T*> { // partial specialization

};
template<template<class U> class V> class C {

int x;

long x;

V<int>
y;
V<int*> z;

};
C<A> c;

// V<int> within C<A> uses the primary template,
// so c.y.x has type int

§ 14.3.3

343

c(cid:13) ISO/IEC

