int main()
{
// OK

class complex { /* ... */ };
typedef int complex;


4

5

6


return 0;
}
