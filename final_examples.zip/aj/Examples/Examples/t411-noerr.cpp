
}

};

};

struct X {

operator double();

struct Y {

operator int*();

int *a = Y() + 100.0;
int *b = Y() + X();


