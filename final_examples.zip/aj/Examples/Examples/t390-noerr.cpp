
class Thing {
public:

Thing();
~Thing();
Thing(Thing&&);

private:

Thing(const Thing&);

};

}

Thing f(bool b) {

Thing t;
if (b)

throw t;
return t;

// OK: Thing(Thing&&) used (or elided) to throw t
// OK: Thing(Thing&&) used (or elided) to return t

Thing t2 = f(false);

// OK: Thing(Thing&&) used (or elided) to construct t2

