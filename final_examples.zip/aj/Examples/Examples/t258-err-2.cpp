
// ra refers to A subobject in b
// rca refers to A subobject in b
// ir refers to the result of B::operator int&

double& rd2 = 2.0;
int
double& rd3 = i;

i = 2;


// error: type mismatch and reference not const

