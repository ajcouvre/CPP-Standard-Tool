
struct X {
X(int);
X(const char*, int =0);
X(int, int);

};

void f(X arg) {

X a = 1;
X b = "Jessie";
a = 2;
f(3);
f({1, 2});

}

// a = X(1)
// b = X("Jessie",0)
// a = X(2)
// f(X(3))
// f(X(1,2))

