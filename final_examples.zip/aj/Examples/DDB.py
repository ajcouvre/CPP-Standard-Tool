import glob
import subprocess

file_list = glob.glob('./*.cpp')
for x  in file_list:
	#print x
	proc = subprocess.Popen(['./select-headers.sh', 'CPP_Headers.h', x, 'g++-trunk'])
	proc.wait()
