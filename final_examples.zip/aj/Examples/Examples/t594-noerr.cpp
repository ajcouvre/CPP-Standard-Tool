
template<class T, class... U> void f(T*, U...) { }
template<class T>
template void f(int*);

void f(T) { }

// selects #1

// #1
// #2

