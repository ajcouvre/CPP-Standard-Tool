argument deductions:

7

template<class T> void f(T x, T y) { /* ... */ }
struct A { /* ... */ };
struct B : A { /* ... */ };
void g(A a, B b) {

f(a,b);
f(b,a);
f(a,a);
f(b,b);

// error: T could be A or B
// OK: T is A
// OK: T is B

}

}

}

Here is an example where two template arguments are deduced from a single function parameter/argument
pair. This can lead to conﬂicts that cause type deduction to fail:
);

template <class T, class U> void f(

T (*)( T, U, U )

int g1( int, float, float);
char g2( int, float, float);
int g3( int, char, float);

void r() {

f(g1);
f(g2);
f(g3);

// OK: T is int and U is float

Here is an example where a qualiﬁcation conversion applies between the argument type on the function call
and the deduced template argument type:
template<class T> void f(const T*) { }
int* p;
void s() {

f(p);

// f(const int*)

Here is an example where the template argument is used to instantiate a derived class type of the corre-
sponding function parameter type:

template <class T> struct B { };
template <class T> struct D : public B<T> {};
struct D2 : public B<int> {};
template <class T> void f(B<T>&){}
void t() {
D<int> d;
D2
d2;
f(d);
f(d2);

// calls f(B<int>&)
// calls f(B<int>&)

}

§ 14.8.2.5

406

c(cid:13) ISO/IEC

