int main()
{
2

T(a)->m = 7;
T(a)++;
T(a,5)<<c;

// expression-statement
// expression-statement
// expression-statement

T(*d)(int);
T(e)[5];
T(f) = { 1, 2 };
T(*g)(double(3));

// declaration
// declaration
// declaration
// declaration

In the last example above, g, which is a pointer to T, is initialized to double(3). This is of course ill-formed

return 0;
}
