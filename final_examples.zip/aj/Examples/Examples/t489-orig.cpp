
class A {

template<class T> friend class B;
template<class T> friend void f(T){ /* ...

// OK
*/ } // OK

§ 14.5.4

353

c(cid:13) ISO/IEC

};

