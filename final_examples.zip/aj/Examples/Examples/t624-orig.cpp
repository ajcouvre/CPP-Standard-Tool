
6

#define str(s)
#define xstr(s)
#define debug(s, t) printf("x" # s "= %d, x" # t "= %s", \

# s
str(s)

x ## s, x ## t)

§ 16.3.5

433

c(cid:13) ISO/IEC

N4296

vers ## n
a ## b

#define INCFILE(n)
#define glue(a, b)
#define xglue(a, b) glue(a, b)
#define HIGHLOW
#define LOW

"hello"
LOW ", world"

debug(1, 2);
fputs(str(strncmp("abc\0d", "abc", ’\4’) // this goes away

== 0) str(: @\n), s);

#include xstr(INCFILE(2).h)
glue(HIGH, LOW);
xglue(HIGH, LOW)

results in

printf("x" "1" "= %d, x" "2" "= %s", x1, x2);
fputs("strncmp(\"abc\\0d\", \"abc\", ’\\4’) == 0" ": @\n", s);
#include "vers2.h"
"hello";
"hello" ", world"

(after macro replacement, before file access)

or, after concatenation of the character string literals,

printf("x1= %d, x2= %s", x1, x2);
fputs("strncmp(\"abc\\0d\", \"abc\", ’\\4’) == 0: @\n", s);
#include "vers2.h"
"hello";
"hello, world"

(after macro replacement, before file access)

