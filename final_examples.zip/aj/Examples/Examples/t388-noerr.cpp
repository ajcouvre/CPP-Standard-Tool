
struct V { };
struct A : virtual V { };
struct B : virtual V { };
struct C : B, A { };

It is unspeciﬁed whether the virtual base class subobject V is assigned twice by the implicitly-deﬁned copy-
