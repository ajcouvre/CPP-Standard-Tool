#!/usr/bin/env bash
readonly header=$1
readonly file=/home/aj/aj/examples/tmp.reduction.test.t119-noerr.cpp
cat $header /home/aj/aj/examples/t119-noerr.cpp > $file 
timeout -s 9 100 g++-trunk  -Wfatal-errors -std=c++14 -c  ${file} &> /dev/null 
exit $?
