int x;

§ 9.7

240

c(cid:13) ISO/IEC

int y;

struct enclose {

int x;
static int s;

N4296

struct inner {

void f(int i) {

int a = sizeof(x);
x = i;
s = i;
::x = i;
y = i;

}
void g(enclose* p, int i) {

p->x = i;

}

};

};

inner* p = 0;

