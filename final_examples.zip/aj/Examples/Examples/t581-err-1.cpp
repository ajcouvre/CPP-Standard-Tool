
template <class T> int f(T&& heisenreference);
template <class T> int g(const T&&);
int i;
int n1 = f(i);
int n2 = f(0);
int n3 = g(i);

// calls f<int&>(int&)
// calls f<int>(int&&)
// error: would call g<int>(const int&&), which
// would bind an rvalue reference to an lvalue

4

