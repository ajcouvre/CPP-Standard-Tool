
§ 3.4.3.2

55

c(cid:13) ISO/IEC

N4296

namespace A {

struct x { };
int x;
int y;

namespace B {

struct y { };

}

}

}

namespace C {

using namespace A;
using namespace B;
int i = C::x;
int j = C::y;

// OK, A::x (of type int )
// ambiguous, A::y or B::y

7

