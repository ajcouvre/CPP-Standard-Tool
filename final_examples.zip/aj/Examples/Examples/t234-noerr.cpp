
struct S {

constexpr S() = default;
S(int a = 0) = default;
void operator=(const S&) = default;
~S() throw(int) = default;

private:
int i;
S(S&);

};
S::S(S&) = default;

// ill-formed: implicit S() is not constexpr
// ill-formed: default argument
// ill-formed: non-matching return type
// deleted: exception speciﬁcation does not match

// OK: private copy constructor

// OK: deﬁnes copy constructor

103) Implementations are permitted to provide additional predeﬁned variables with names that are reserved to the implemen-
tation (2.10). If a predeﬁned variable is not odr-used (3.2), its string value need not be present in the program image.

§ 8.4.2

208

c(cid:13) ISO/IEC

