int main()
{
namespace B {
void f(int);
void f(double);

}
namespace C {
void f(int);
void f(double);
void f(char);

}

void h() {

using B::f;

§ 7.3.3

// B::f(int) and B::f(double)

177

c(cid:13) ISO/IEC

using C::f;
f(’h’);
f(1);
void f(int);

}

// C::f(int), C::f(double), and C::f(char)
// calls C::f(char)
// error: ambiguous: B::f(int) or C::f(int)?
// error: f(int) conﬂicts with C::f(int) and B::f(int)

N4296


return 0;
}
