int main()
{
void h(unsigned Pc);
void k(unsigned int Pc);

// void h(unsigned int)
// void k(unsigned int)


return 0;
}
