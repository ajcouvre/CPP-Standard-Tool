
template<class T> struct A { ~A() = delete; };
template<class T> auto h()

-> A<T>;

-> T;

template<class T> auto i(T)

template<class T> auto f(T)

-> decltype(i(h<T>()));

template<class T> auto f(T)

-> void;

auto g() -> void {

f(42);

}
template<class T> auto q(T)

-> decltype((h<T>()));

void r() {

§ 7.1.6.2

// identity

// #1
// forces completion of A<T> and implicitly uses
// A<T>::~A() for the temporary introduced by the
// use of h(). (A temporary is not introduced
// as a result of the use of i().)
// #2

// OK: calls #2. (#1 is not a viable candidate: type
// deduction fails (14.8.2) because A<int>::~A()
// is implicitly used in its decltype-speciﬁer)

// does not force completion of A<T>; A<T>::~A() is
// not implicitly used within the context of this decltype-speciﬁer

161

c(cid:13) ISO/IEC

q(42);

}

N4296

// Error: deduction against q succeeds, so overload resolution
// selects the specialization “q(T) -> decltype((h<T>())) [with T=int]”.
// The return type is A<int>, so a temporary is introduced and its
// destructor is used, so the program is ill-formed.

