int main()
{
class B : public A {

using A::f;

public:

using A::g;

// error: A::f(char) is inaccessible

// B::g is a public synonym for A::g

19


return 0;
}
