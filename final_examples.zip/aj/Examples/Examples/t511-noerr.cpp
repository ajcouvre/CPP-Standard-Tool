
template<typename...> using void_t = void;
template<typename T> void_t<typename T::foo> f();

