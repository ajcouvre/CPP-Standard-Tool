int main()
{// cv-qualiﬁed (initialized as required)
// ill-formed: attempt to modify const

const int ci = 3;
ci = 4;

int i = 2;
const int* cip;
cip = &i;
*cip = 4;

// not cv-qualiﬁed
// pointer to const int
// OK: cv-qualiﬁed access path to unqualiﬁed
// ill-formed: attempt to modify through ptr to const

int* ip;
ip = const_cast<int*>(cip);
*ip = 4;

// cast needed to convert const int* to int*
// deﬁned: *ip points to i, a non-const object

const int* ciq = new const int (3);
int* iq = const_cast<int*>(ciq);
*iq = 4;

// initialized as required
// cast required
// undeﬁned: modiﬁes a const object

5 For another example

struct X {

mutable int i;
int j;

};
struct Y {

X x;
Y();

};

const Y y;
y.x.i++;
y.x.j++;
Y* p = const_cast<Y*>(&y);
p->x.i = 99;
p->x.j = 99;

// well-formed: mutable member can be modiﬁed
// ill-formed: const-qualiﬁed member modiﬁed
// cast away const-ness of y
// well-formed: mutable member can be modiﬁed
// undeﬁned: modiﬁes a const member


return 0;
}
