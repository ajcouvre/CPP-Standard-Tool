
struct X {

typedef int I;
class Y { /* ... */ };
I a;

};

// error
// OK
// OK

I b;
Y c;
X::Y d;
X::I e;

