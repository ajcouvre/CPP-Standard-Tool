
template <class... Types> class Tuple;

template <class T, int... Dims> struct multi_array;

template<class... T> struct value_holder {
template<T... Values> struct apply { };

// Types is a template type parameter pack
// but not a pack expansion
// Dims is a non-type template parameter pack
// but not a pack expansion

// Values is a non-type template parameter pack
// and a pack expansion

};
template<class... T, T... Values> struct static_array;// error: Values expands template type parameter
// pack T within the same template parameter list

