
void f(const char*);
void g() {

extern void f(int);
f("asdf");

}

void caller () {

extern void callee(int, int);
{

extern void callee(int);
callee(88, 99);

}

}

// so there is no f(const char*) in this scope

// hides callee(int, int)

