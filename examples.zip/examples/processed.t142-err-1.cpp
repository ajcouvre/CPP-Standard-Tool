int main()
{
constexpr int square(int x)

{ return x * x; }

constexpr long long_max()
{ return 2147483647; }

constexpr int abs(int x) {

if (x < 0)
x = -x;
return x;

// OK

// OK

// OK

// error: variable has static storage duration


}
constexpr int first(int n) {

static int value = n;
return value;

}
constexpr int uninit() {

int a;
return a;

}
constexpr int prev(int x)

{ return --x; }

// OK
constexpr int g(int x, int n) { // OK

int r = 1;
while (--n > 0) r *= x;
return r;

}


return 0;
}
