subexpression, but not the second S::x subexpression.

struct S { static const int x = 0; };
const int &f(const int &r);
int n = b ? (1, S::x) // S::x is not odr-used here
// S::x is odr-used here, so
// a deﬁnition is required

: f(S::x);

