
template <class T> struct Base {

Base* p;

};

template <class T> struct Derived: public Base<T> {

typename Derived::Base* p;

// meaning Derived::Base<T>

§ 14.6.1

368

c(cid:13) ISO/IEC

};

N4296

template<class T, template<class> class U = T::template Base> struct Third { };
Third<Base<int> > t;

// OK: default argument uses injected-class-name as a template

