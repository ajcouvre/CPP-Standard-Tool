volatile int> evaluates to int, whereas remove_cv_t<const
