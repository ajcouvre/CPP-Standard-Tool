
//translation unit 1:
struct X {
X(int);
X(int, int);

};
X::X(int = 0) { }
class D: public X { };
D d2;

//translation unit 2:
struct X {
X(int);

// X(int) called by D()

27) 8.3.6 describes how default argument names are looked up.

§ 3.2

38

c(cid:13) ISO/IEC

N4296

X(int, int);

};
X::X(int = 0, int = 0) { }
class D: public X { };

