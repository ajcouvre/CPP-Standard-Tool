
int f(void(&)());
int f(void(&&)());
void g();
int i1 = f(g);

// #1
// #2

// calls #1

(3.2.5)

—

