int main()
{
3

int i = 42;
int a[10];

for (int i = 0; i < 10; i++)

a[i] = i;

int j = i;

// j = 42


return 0;
}
