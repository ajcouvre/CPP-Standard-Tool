
struct S {
class A;
enum E : int;

private:

};

// error: cannot change access
class A { };
enum E: int { e0 }; // error: cannot change access

5

