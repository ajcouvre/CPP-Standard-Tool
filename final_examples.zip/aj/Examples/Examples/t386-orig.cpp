
struct X {

X();
X& operator=(X&);

};
const X cx;
X x;
void f() {
x = cx;

}

// error: X::operator=(X&) cannot assign cx into x

18

