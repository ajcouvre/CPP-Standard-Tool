138) There is no such ambiguity in a default template-argument because the form of the template-parameter determines the
allowable forms of the template-argument.

§ 14.3

340

c(cid:13) ISO/IEC

N4296

template<class T = char> class String;
String<>* p;
String* q;
template<class ... Elements> class Tuple;
Tuple<>* t;
Tuple* u;

// OK: String<char>

// OK: Elements is empty

