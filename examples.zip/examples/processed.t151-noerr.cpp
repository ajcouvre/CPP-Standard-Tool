int main()
{
3

auto glambda = [](int i, auto a) { return i; }; // OK: a generic lambda


return 0;
}
