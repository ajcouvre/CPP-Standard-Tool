
4

new int(*[10])();


is ill-formed because the binding is

(new int) (*[10])();

// error

§ 5.3.4

116

c(cid:13) ISO/IEC

N4296

Instead, the explicitly parenthesized version of the new operator can be used to create objects of compound
types (3.9.2):

new (int (*[10])());

