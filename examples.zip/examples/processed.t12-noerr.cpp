int main()
{
long double operator "" _w(long double);
std::string operator "" _w(const char16_t*, std::size_t);
unsigned operator "" _w(const char*);
int main() {

1.2_w;
u"one"_w;
12_w;
"two"_w;

// calls operator "" _w(1.2L)
// calls operator "" _w(u"one", 3)
// calls operator "" _w("12")

}

}


return 0;
}
