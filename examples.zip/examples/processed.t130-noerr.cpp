int main()
{
static char* f();
char* f()

{ /* ... */ }

char* g();
static char* g()

{ /* ... */ }

void h();
inline void h();

inline void l();
void l();

inline void m();
extern void m();

static void n();
inline void n();

§ 7.1.1

// f() has internal linkage
// f() still has internal linkage

// g() has external linkage

// external linkage

// external linkage

// external linkage

// internal linkage

150

N4296

c(cid:13) ISO/IEC

static int a;
int a;

static int b;
extern int b;

int c;
static int c;

extern int d;
static int d;


return 0;
}
