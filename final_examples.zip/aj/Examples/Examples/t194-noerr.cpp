
int p[10];
void f() {

int x = 42, y[5];
int(p[[x] { return x; }()]);

y[[] { return 2; }()] = 2;

}

// declarator-id and not a function-style cast of
// an element of p.
// in this context.

