int main()
{
void f() {

// ...
goto lx;
// ...

ly:

lx:

X a = 1;
// ...

goto ly;

}


return 0;
}
