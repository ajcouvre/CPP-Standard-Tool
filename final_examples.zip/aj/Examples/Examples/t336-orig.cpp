
class Y {

friend char* X::foo(int);
friend X::X(char);
friend X::~X();

};

// constructors can be friends
// destructors can be friends

