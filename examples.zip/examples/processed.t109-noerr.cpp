int main()
{
2

f(a, (t=3, t+2), c);


return 0;
}
