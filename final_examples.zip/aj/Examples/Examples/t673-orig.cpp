reusing the numpunct<charT> facet interface:

// ﬁle: my_bool.C
#include <iostream>
#include <locale>
#include <string>
namespace My {

using namespace std;
typedef numpunct_byname<char> cnumpunct;

§ 22.4.8

741

c(cid:13) ISO/IEC

N4296

class BoolNames : public cnumpunct {
protected:

string do_truename()
const { return "Oui Oui!"; }
string do_falsename() const { return "Mais Non!"; }
~BoolNames() { }

BoolNames(const char* name) : cnumpunct(name) { }

public:

};

}

int main(int argc, char** argv) {

using namespace std;
// make the user’s preferred locale, except for...
locale loc(locale(""), new My::BoolNames(""));
cout.imbue(loc);
cout << boolalpha << "Any arguments today? " << (argc > 1) << endl;
return 0;

}

