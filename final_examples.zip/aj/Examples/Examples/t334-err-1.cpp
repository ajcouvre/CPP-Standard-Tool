
class A {

friend class B { }; // error: cannot deﬁne class in friend declaration

