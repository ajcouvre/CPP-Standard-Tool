
class A { };
class B : private A { };
class C : public B {

A* p;
::A* q;

};

// error: injected-class-name A is inaccessible
// OK

