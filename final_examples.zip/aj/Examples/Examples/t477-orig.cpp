
template<class T> struct string {

template<class T2> int compare(const T2&);
template<class T2> string(const string<T2>& s) { /* ... */ }

};

template<class T> template<class T2> int string<T>::compare(const T2& s) {
}

