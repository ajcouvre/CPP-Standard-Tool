
extern "C" typedef void FUNC_c();
class C {

void mf1(FUNC_c*);

FUNC_c mf2;

static FUNC_c* q;

};

extern "C" {
class X {
void mf();

void mf2(void(*)());

};

}

// the name of the function mf1 and the member
// function’s type have C++ language linkage; the
// parameter has type pointer to C function
// the name of the function mf2 and the member
// function’s type have C++ language linkage
// the name of the data member q has C++ language
// linkage and the data member’s type is pointer to
// C function

// the name of the function mf and the member
// function’s type have C++ language linkage
// the name of the function mf2 has C++ language
// linkage; the parameter has type pointer to
// C function

5

