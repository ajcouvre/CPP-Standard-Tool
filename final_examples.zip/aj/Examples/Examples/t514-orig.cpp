
struct A {

struct X { };
int X;

};
struct B {

struct X { };

};
template<class T> void f(T t) {

typename T::X x;

}
void foo() {

A a;
B b;
f(b);
f(a);

}

// OK: T::X refers to B::X
// error: T::X refers to the data member A::X not the struct A::X

