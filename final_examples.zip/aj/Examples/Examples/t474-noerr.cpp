
template<class T> class X {

static T s;

};
template<class T> T X<T>::s = 0;

§ 14.5.1.3

347

c(cid:13) ISO/IEC

N4296

struct limits {

template<class T>

static const T min;

};

// declaration

template<class T>

const T limits::min = { };

// deﬁnition

