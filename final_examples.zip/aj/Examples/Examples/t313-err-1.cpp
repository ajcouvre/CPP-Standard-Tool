111) A function with the same name but a diﬀerent parameter list (Clause 13) as a virtual function is not necessarily virtual
and does not override. The use of the virtual speciﬁer in the declaration of an overriding function is legal but redundant (has
empty semantics). Access control (Clause 11) is not considered in determining overriding.

§ 10.3

250

c(cid:13) ISO/IEC

N4296

struct B {

};

virtual void f() const final;

struct D : B {

void f() const;

};

// error: D::f attempts to override final B::f

5

