
const int ci = 10, *pc = &ci, *const cpc = pc, **ppc;
int i, *p, *const cp = &i;

declare ci, a constant integer; pc, a pointer to a constant integer; cpc, a constant pointer to a constant
integer; ppc, a pointer to a pointer to a constant integer; i, an integer; p, a pointer to integer; and cp, a
constant pointer to integer. The value of ci, cpc, and cp cannot be changed after initialization. The value
of pc can be changed, and so can the object pointed to by cp. Examples of some correct operations are

i = ci;
*cp = ci;
pc++;
pc = cpc;

§ 8.3.1

195

N4296

c(cid:13) ISO/IEC

pc = p;
ppc = &pc;

Examples of ill-formed operations are

ci = 1;
ci++;
*pc = 2;
cp = &ci;
cpc++;
p = pc;
ppc = &p;


Each is unacceptable because it would either change the value of an object declared const or allow it to be
changed through a cv-unqualiﬁed pointer later, for example:
// OK, but would make p point to ci ...
// ... because of previous error
// clobber ci

*ppc = &ci;

*p = 5;

