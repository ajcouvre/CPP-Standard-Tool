
template<class T1> class A {

template<class T2> class B {

void mf();

};

};
template<> template<> class A<int>::B<double>;
template<> template<> void A<char>::B<char>::mf();

16

