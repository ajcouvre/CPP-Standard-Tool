
template<> class X<int> { /* ... */ };


template<class T> class X;
template<> class X<char*> { /* ... */ };

// OK: X is a template

