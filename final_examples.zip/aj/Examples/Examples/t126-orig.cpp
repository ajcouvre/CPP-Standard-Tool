
5

// ill-formed
enum { };
typedef class { }; // ill-formed

6

