
struct X { int a; };
struct Y { int a; };
X a1;
Y a2;
int a3;

declares three variables of three diﬀerent types. This implies that

a1 = a2;
a1 = a3;


are type mismatches, and that

int f(X);
int f(Y);

declare an overloaded (Clause 13) function f() and not simply a single function f() twice. For the same
reason,

struct S { int a; };
struct S { int a; };

// error, double deﬁnition

