
struct stat {

// ...

};

stat gstat;

// use plain stat to
// deﬁne variable

int stat(struct stat*);

// redeclare stat as function

void f() {

struct stat* ps;

stat(ps);

}

// struct preﬁx needed
// to name struct stat
// call stat()

