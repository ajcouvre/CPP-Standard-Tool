int main()
{
5

// ill-formed
enum { };
typedef class { }; // ill-formed

6


return 0;
}
