members m of type M and n of type N. If M has a non-trivial destructor and N has a non-trivial constructor
(for instance, if they declare or inherit virtual functions), the active member of u can be safely switched
from m to n using the destructor and placement new operator as follows:

u.m.~M();

§ 9.5

238

c(cid:13) ISO/IEC

new (&u.n) N;
