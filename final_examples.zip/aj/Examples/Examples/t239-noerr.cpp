
struct sometype {

sometype();

};
sometype::sometype() = delete;

// ill-formed; not ﬁrst declaration

