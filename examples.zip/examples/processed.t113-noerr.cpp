int main()
{
if (x)

int i;

can be equivalently rewritten as

if (x) {
int i;

}


return 0;
}
