int main()
{
f() { } // OK, return type is void

auto
auto* g() { } // error, cannot deduce auto* from void()

§ 7.1.6.4

164

c(cid:13) ISO/IEC

N4296

11


return 0;
}
