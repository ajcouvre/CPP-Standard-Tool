int main()
{
enum { a, b, c=0 };
enum { d, e, f=e+2 };


return 0;
}
