int main()
{
6

7

constexpr A(int i) : val(i) { }
constexpr operator int() const { return val; }
constexpr operator long() const { return 43; }

struct A {

private:

int val;

};
template<int> struct X { };
constexpr A a = 42;
X<a> x;
int ary[a];
88) Nonetheless, implementations are encouraged to provide consistent results, irrespective of whether the evaluation was
performed during translation and/or during program execution.

// OK: unique conversion to int

§ 5.20

135

c(cid:13) ISO/IEC


return 0;
}
