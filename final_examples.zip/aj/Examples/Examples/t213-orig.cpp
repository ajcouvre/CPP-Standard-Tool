
4

float fa[17], *afp[17];

declares an array of float numbers and an array of pointers to float numbers. For another example,

static int x3d[3][5][7];

declares a static three-dimensional array of integers, with rank 3× 5× 7. In complete detail, x3d is an array
of three items; each item is an array of ﬁve arrays; each of the latter arrays is an array of seven integers.
Any of the expressions x3d, x3d[i], x3d[i][j], x3d[i][j][k] can reasonably appear in an expression.
Finally,

extern int x[10];
struct S {

static int y[10];

};

int x[];
int S::y[];

// OK: bound is 10
// OK: bound is 10

void f() {

extern int x[];
int i = sizeof(x);

}

// error: incomplete object type

