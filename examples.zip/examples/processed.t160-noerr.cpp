int main()
{
auto f();
auto f() { return 42; } // return type is int
auto f();
int f();
decltype(auto) f();

// OK

template <typename T> auto g(T t) { return t; } // #1
template auto g(int);
template char g(char);
template<> auto g(double);

// OK, return type is int
// OK, forward declaration with unknown return type

template <class T> T g(T t) { return t; } // OK, not functionally equivalent to #1
// OK, now there is a matching template
template char g(char);
// still matches #1
template auto g(float);


template <typename T> struct A {

friend T frf(T);

};
auto frf(int i) { return i; } // not a friend of A<int>

§ 7.1.6.4

165

c(cid:13) ISO/IEC


return 0;
}
