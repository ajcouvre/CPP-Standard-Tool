
void f(int, int);
void g(int i, int* v) {

i = v[i++];
i = 7, i++, i++;

// the behavior is undeﬁned
// i becomes 9

i = i++ + 1;
i = i + 1;

// the behavior is undeﬁned
// the value of i is incremented

f(i = -1, i = -1); // the behavior is undeﬁned

8) As speciﬁed in 12.2, after a full-expression is evaluated, a sequence of zero or more invocations of destructor functions for

temporary objects takes place, usually in reverse order of the construction of each temporary object.

§ 1.9

10

c(cid:13) ISO/IEC

}

N4296

