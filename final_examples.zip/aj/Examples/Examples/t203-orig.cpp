
struct S {
S(int);

};

void foo(double a) {

S w(int(a));
S x(int());
S y((int)a);
S z = int(a);

// function declaration
// function declaration
// object declaration
// object declaration

}

}

