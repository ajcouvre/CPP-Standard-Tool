constructor and copy assignment operator, and then providing defaulted deﬁnitions of the move constructor
and move assignment operator.

struct moveonly {

moveonly() = default;
moveonly(const moveonly&) = delete;
moveonly(moveonly&&) = default;
moveonly& operator=(const moveonly&) = delete;
moveonly& operator=(moveonly&&) = default;
~moveonly() = default;

};
moveonly* p;

