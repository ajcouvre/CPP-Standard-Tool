
3

#include <cstddef>
char* p;
void* operator new(std::size_t, int);
void foo() {

const int x = 63;
new (int(*p)) int;
new (int(*[x]));

// new-placement
// parenthesized type-id

4 For another example,
template <class T>
struct S {

T* p;

};

§ 8.2

193

c(cid:13) ISO/IEC

S<int()> x;
S<int(1)> y;

5 For another example,

void foo() {

sizeof(int(1));
sizeof(int());

}

6 For another example,

void foo() {
(int(1));
(int())1;

}

