
template<class E, int size> class buffer { /* ... */ };
buffer<char,2*512> x;
buffer<char,1024> y;

declares x and y to be of the same type, and

template<class T, void(*err_fct)()> class list { /* ... */ };

declares x2 and x3 to be of the same type. Their type diﬀers from the types of x1 and x4.

template<class T> struct X { };
template<class> struct Y { };
template<class T> using Z = Y<T>;
X<Y<int> > y;
X<Z<int> > z;

2

