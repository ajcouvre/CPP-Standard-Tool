
[[noreturn]] void f [[noreturn]] (); // OK

