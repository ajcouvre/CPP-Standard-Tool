
void f() {

D d;
B* pb = &d;
D* pd = &d;

pb->f();

pd->f();

}

