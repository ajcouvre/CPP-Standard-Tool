
struct Y { Y(int); };
struct A { operator int(); };
Y y1 = A();


struct X { };
struct B { operator X(); };
B b;
X x({b});

// error: B::operator X() is not a candidate

