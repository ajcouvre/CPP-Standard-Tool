int main()
{example ] Either the integer part or the fraction part (not both) can be omitted; either the decimal point
or the letter e (or E ) and the exponent (not both) can be omitted. The integer part, the optional decimal
point and the optional fraction part form the signiﬁcant part of the ﬂoating literal. The exponent, if present,
indicates the power of 10 by which the signiﬁcant part is to be scaled. If the scaled value is in the range
of representable values for its type, the result is the scaled value if representable, else the larger or smaller
representable value nearest the scaled value, chosen in an implementation-deﬁned manner. The type of a
ﬂoating literal is double unless explicitly speciﬁed by a suﬃx. The suﬃxes f and F specify float, the suﬃxes
l and L specify long double. If the scaled value is not in the range of representable values for its type, the
program is ill-formed.
2.13.5 String literals

[lex.string]

string-literal:

encoding-preﬁxopt" s-char-sequenceopt"
encoding-preﬁxoptR raw-string

s-char-sequence:

s-char
s-char-sequence s-char

s-char:

any member of the source character set except

the double-quote ", backslash \, or new-line character

escape-sequence
universal-character-name

raw-string:

" d-char-sequenceopt( r-char-sequenceopt) d-char-sequenceopt"

r-char-sequence:

r-char
r-char-sequence r-char

r-char:

any member of the source character set, except

a right parenthesis ) followed by the initial d-char-sequence
(which may be empty) followed by a double quote ".

d-char-sequence:

d-char
d-char-sequence d-char

§ 2.13.5

28

c(cid:13) ISO/IEC

N4296

d-char:

any member of the basic source character set except:

space, the left parenthesis (, the right parenthesis ), the backslash \,
and the control characters representing horizontal tab,
vertical tab, form feed, and newline.

1 A string-literal is a sequence of characters (as deﬁned in 2.13.3) surrounded by double quotes, optionally
preﬁxed by R, u8, u8R, u, uR, U, UR, L, or LR, as in "...", R"(...)", u8"...", u8R"**(...)**", u"...",
uR"*~(...)*~", U"...", UR"zzz(...)zzz", L"...", or LR"(...)", respectively.

3

2 A string-literal that has an R in the preﬁx is a raw string literal. The d-char-sequence serves as a delimiter.
The terminating d-char-sequence of a raw-string is the same sequence of characters as the initial d-char-
sequence. A d-char-sequence shall consist of at most 16 characters.
[ Note: The characters ’(’ and ’)’ are permitted in a raw-string. Thus, R"delimiter((a|b))delimiter"
is equivalent to "(a|b)". — end note ]
[ Note: A source-ﬁle new-line in a raw string literal results in a new-line in the resulting execution string-
literal. Assuming no whitespace at the beginning of lines in the following example, the assert will succeed:

4

const char* p = R"(a\
b
c)";
assert(std::strcmp(p, "a\\\nb\nc") == 0);

— end note ]

5

R"a(
)\
a"
)a"

is equivalent to "\n)\\\na\"\n". The raw string

R"(??)"

is equivalent to "\?\?". The raw string

R"#(
)??="
)#"


return 0;
}
