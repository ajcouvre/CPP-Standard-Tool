
12

struct A {

virtual void f();

};

struct B1 : A {

void f();

};

// note non-virtual derivation

struct B2 : A {

void f();

};

§ 10.3

252

c(cid:13) ISO/IEC

N4296

struct D : B1, B2 {
};

// D has two separate A subobjects

// A* ap = &d; // would be ill-formed: ambiguous

// calls D::B1::f
// ill-formed: ambiguous

In class D above there are two occurrences of class A and hence two occurrences of the virtual member
function A::f. The ﬁnal overrider of B1::A::f is B1::f and the ﬁnal overrider of B2::A::f is B2::f.

13 The following example shows a function that does not have a unique ﬁnal overrider:

void foo() {

D

d;

b1p = &d;
ap = b1p;
dp = &d;

B1*
A*
D*
ap->f();
dp->f();

struct A {

virtual void f();

}

};

};

};

struct VB1 : virtual A {

// note virtual derivation

void f();

struct VB2 : virtual A {

void f();

struct Error : VB1, VB2 {
};

// ill-formed

struct Okay : VB1, VB2 {

void f();

};

Both VB1::f and VB2::f override A::f but there is no overrider of both of them in class Error. This
example is therefore ill-formed. Class Okay is well formed, however, because Okay::f is a ﬁnal overrider.

14 The following example uses the well-formed classes from above.

struct VB1a : virtual A {
};

struct Da : VB1a, VB2 {
};

// does not declare f

void foe() {

VB1a*
vb1ap->f();

}

vb1ap = new Da;

// calls VB2::f

