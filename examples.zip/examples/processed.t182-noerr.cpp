int main()
{
namespace A {

int x;

}

namespace B {

int i;
struct g { };
struct x { };
void f(int);
void f(double);
void g(char);

}

}

void func() {

int i;
using B::i;
void f(char);
using B::f;
f(3.5);
using B::g;
g(’a’);
struct g g1;
using B::x;
using A::x;
x = 99;
struct x x1;

// OK: hides struct g


// OK: each f is a function
// calls B::f(double)

// calls B::g(char)
// g1 has class type B::g

// OK: hides struct B::x
// assigns to A::x
// x1 has class type B::x

14


return 0;
}
