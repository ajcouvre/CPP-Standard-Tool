
char cv[4] = "asdf";


