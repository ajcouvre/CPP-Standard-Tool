
constexpr explicit Length(int i = 0) : val(i) { }

struct Length {

private:

int val;

};

