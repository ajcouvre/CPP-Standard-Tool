
typedef unsigned char T;
template<class T

N = 0> struct A { };

= T
, T

// lookup ﬁnds the typedef name of unsigned char
// lookup ﬁnds the template parameter

11

12

