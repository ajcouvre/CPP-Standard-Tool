
#include <string>

struct C {

std::string s;

};

// std::string is the standard library class (Clause 21)

int main() {

C a;
C b = a;
b = a;

}

the implementation will implicitly deﬁne functions to make the deﬁnition of C equivalent to
25) Appearing inside the braced-enclosed declaration-seq in a linkage-speciﬁcation does not aﬀect whether a declaration is a
deﬁnition.

§ 3.1

35

c(cid:13) ISO/IEC

N4296

struct C {

std::string s;
C() : s() { }
C(const C& x): s(x.s) { }
C(C&& x): s(static_cast<std::string&&>(x.s)) { }

// : s(std::move(x.s)) { }

C& operator=(const C& x) { s = x.s; return *this; }
C& operator=(C&& x) { s = static_cast<std::string&&>(x.s); return *this; }

// { s = std::move(x.s); return *this; }

~C() { }

};

