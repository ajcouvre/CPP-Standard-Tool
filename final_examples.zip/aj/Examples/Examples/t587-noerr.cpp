
11

// #1
template <class T> T f(int);
template <class T, class U> T f(U); // #2
void g() {

}

f<int>(1);

// calls #1

12

