int main()
{
namespace A::B::C {

int i;

}

The above has the same eﬀect as:

namespace A {

namespace B {

namespace C {

int i;

}

}

}


return 0;
}
