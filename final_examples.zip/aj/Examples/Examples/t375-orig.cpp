
class A {
public:

A(int);

};

class B : public A {

int j;
public:

int f();
B() : A(f()),

j(f()) { }

};

class C {
public:

C(int);

};

// undeﬁned: calls member function
// but base A not yet initialized
// well-deﬁned: bases are all initialized

class D : public B, C {

int i;
public:

D() : C(f()),

i(f()) { }

};

// undeﬁned: calls member function
// but base C not yet initialized
// well-deﬁned: bases are all initialized

17

