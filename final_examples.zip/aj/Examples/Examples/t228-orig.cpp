
int a;
int f(int a, int b = a);

typedef int I;
int g(float I, int b = I(2));
int h(int a, int b = sizeof(a));

// error: parameter a
// used as default argument

// error: parameter I found
// error, parameter a used
// in default argument

