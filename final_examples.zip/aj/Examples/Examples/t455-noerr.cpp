
template<class T> class X {

static T t;

};

class Y {
private:

struct S { /* ... */ };
X<S> x;

// OK: S is accessible
// X<Y::S> has a static member of type Y::S
// OK: even though Y::S is private

};

};

X<Y::S> y;


