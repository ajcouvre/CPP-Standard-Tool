
template<class T> void f(T);
template<class T> void f(T*, int=1);
template<class T> void g(T);
template<class T> void g(T*, ...);

// #1
// #2
// #3
// #4

int main() {

int* ip;
f(ip);
g(ip);

}

// calls #2
// calls #4

