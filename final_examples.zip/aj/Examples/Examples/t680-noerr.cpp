
2

list<string> s;
// populate the list s
vector<string> v1(s.begin(), s.end());
vector<string> v2(make_move_iterator(s.begin()),

// copies strings into v1

make_move_iterator(s.end())); // moves strings into v2

