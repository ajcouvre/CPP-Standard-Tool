
struct s { int a; };

void g() {
struct s;

§ 9.1

// hide global struct s

229

c(cid:13) ISO/IEC

N4296

s* p;
struct s { char* p; };
struct s;

}

// with a block-scope declaration
// refer to local struct s
// deﬁne local struct s
// redeclaration, has no eﬀect

