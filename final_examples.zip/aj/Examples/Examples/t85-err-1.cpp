
template<typename ...Args>
bool f(Args ...args) {

return (true && ... && args); // OK

template<typename ...Args>
bool f(Args ...args) {

}

}

return (args + ... + args); // error: both operands contain unexpanded parameter packs

[expr.post]

