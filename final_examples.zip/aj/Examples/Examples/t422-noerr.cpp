
struct A {
int m1;
double m2;

};

void f(A);
f( {’a’, ’b’} );
f( {1.0} );

