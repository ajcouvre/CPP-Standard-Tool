
class X {

void operator delete(void*);
void operator delete[](void*, std::size_t);

class Y {

};

};

void operator delete(void*, std::size_t);
void operator delete[](void*);

