
template <class T> struct A {

void f(int);
template <class U> void f(U);

};

template <class T> void f(T t) {

A<T> a;
a.template f<>(t);
a.template f(t);

}

// OK: calls template

template <class T> struct B {

template <class T2> struct C { };

};

// OK: T::template C names a class template:
template <class T, template <class X> class TT = T::template C> struct D { };
D<B<int> > db;

