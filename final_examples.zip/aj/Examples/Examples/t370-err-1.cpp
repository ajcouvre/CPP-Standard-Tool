
struct A {

A();

};

struct B {
B(int);

};

struct C {
C() { }
A a;
const B b;
int i;
int j = 5;

};

// initializes members as follows:

// OK: calls A::A()
// error: B has no default constructor
// OK: i has indeterminate value
// OK: j has the value 5

10

