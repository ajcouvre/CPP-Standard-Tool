
template<class ... Types> void f(Types ... rest);
template<class ... Types> void g(Types ... rest) {

f(&rest ...);

// “&rest ...” is a pack expansion; “&rest” is its pattern

}

