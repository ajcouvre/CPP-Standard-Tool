int main()
{
if (int x = f()) {

int x;

}
else {

int x;

}

// ill-formed, redeclaration of x

// ill-formed, redeclaration of x


return 0;
}
