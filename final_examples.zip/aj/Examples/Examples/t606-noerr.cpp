
lab:

try {

T1 t1;
try {

T2 t2;
if (condition )

goto lab;

Exception handling

414

c(cid:13) ISO/IEC

} catch(...) { /* handler 2 */ }

} catch(...) { /* handler 1 */ }

N4296

Here, executing goto lab; will destroy ﬁrst t2, then t1, assuming the condition does not declare a variable.
Any exception raised while destroying t2 will result in executing handler 2; any exception raised while
