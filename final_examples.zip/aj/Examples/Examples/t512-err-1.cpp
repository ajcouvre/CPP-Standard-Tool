
template <class T> struct A;
template <class T> using B = typename A<T>::U;
template <class T> struct A {

typedef B<T> U;

};
B<short> b;

// error: instantiation of B<short> uses own type via A<short>::U

