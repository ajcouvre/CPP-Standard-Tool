
struct B {

virtual void f(int);

struct D : B {

};

};

virtual void f(int) override;

// OK

