
a1;
A<int, int, 1>
A<int, int*, 1>
a2;
A<int, char*, 5> a3;
A<int, char*, 1> a4;
A<int*, int*, 2> a5;

