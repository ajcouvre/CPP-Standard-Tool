int main()
{
struct S {

typedef struct A { } A;
typedef struct B B;
typedef A A;

};

// OK
// OK


return 0;
}
