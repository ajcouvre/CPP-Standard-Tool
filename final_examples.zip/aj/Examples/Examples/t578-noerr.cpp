conversion (8.5.4) would be required to convert the template-argument of type int to signed char, therefore
substitution fails for the second template (14.3.2).

template <int> int f(int);
template <signed char> int f(int);
// OK
int i1 = f<1000>(0);
// ambiguous; not narrowing
int i2 = f<1>(0);

