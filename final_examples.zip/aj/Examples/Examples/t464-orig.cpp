
template<const int& CRI> struct B { /* ... */ };

B<1> b2;

int c = 1;
B<c> b1;

// error: temporary would be required for template argument

// OK

