
union u { int a; const char* b; };
u a = { 1 };
u b = a;
u c = 1;
u d = { 0, "asdf" };
u e = { "asdf" };

// error

17

