
template<class T> void sort(Array<T>& v);
void f(Array<dcomplex>& cv, Array<int>& ci) {

sort<dcomplex>(cv);
sort<int>(ci);

// sort(Array<dcomplex>&)
// sort(Array<int>&)

template<class U, class V> U convert(V v);

void g(double d) {

int i = convert<int,double>(d);
char c = convert<char,double>(d);

// int convert(double)
// char convert(double)

}

and

}

