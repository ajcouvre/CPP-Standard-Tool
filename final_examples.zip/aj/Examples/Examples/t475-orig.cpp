
template <class T> struct A {

static int i[];

};
template <class T> int A<T>::i[4];
template <> int A<int>::i[] = { 1 }; // OK: 1 element

// 4 elements

