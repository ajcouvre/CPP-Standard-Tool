
int g(int);
void f() {

int i;
int& r = i;
r = 1;
int* p = &r;
int& rr = r;
int (&rg)(int) = g;
rg(i);
int a[3];
int (&ra)[3] = a;
ra[1] = i;

}

// r refers to i
// the value of i becomes 1
// p points to i
// rr refers to what r refers to, that is, to i
// rg refers to the function g
// calls function g

// ra refers to the array a
// modiﬁes a[1]

