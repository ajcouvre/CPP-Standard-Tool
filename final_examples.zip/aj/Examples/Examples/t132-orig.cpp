
class X {

mutable const int* p;
mutable int* const q;

};

// OK
// ill-formed

