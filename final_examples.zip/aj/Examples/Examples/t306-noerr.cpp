
struct A {
int f();

};

struct B {
int f();

};

struct C : A, B {

int f() { return A::f() + B::f(); }

};

9

