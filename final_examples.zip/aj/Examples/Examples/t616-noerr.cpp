
void f() throw(int);
void g();
struct A { A(); };
struct B { B() noexcept; };
struct D() { D() throw (double); };

the set of potential exceptions for some sample expressions is:

(15.7)

(15.8)

(15.9)

(15.10)

(15.11)

—
—
—
—
—

for f(), the set consists of int;
for g(), the set consists of “any”;
for new A, the set consists of “any”;
for B(), the set is empty;
for new D, the set consists of “any” and double.

