
(ptr_to_obj->*ptr_to_mfct)(10);

calls the member function denoted by ptr_to_mfct for the object pointed to by ptr_to_obj. — end
example ] In a .* expression whose object expression is an rvalue, the program is ill-formed if the second
operand is a pointer to member function with ref-qualiﬁer &. In a .* expression whose object expression is
an lvalue, the program is ill-formed if the second operand is a pointer to member function with ref-qualiﬁer
&&. The result of a .* expression whose second operand is a pointer to a data member is an lvalue if the
ﬁrst operand is an lvalue and an xvalue otherwise. The result of a .* expression whose second operand is a
pointer to a member function is a prvalue. If the second operand is the null pointer to member value (4.11),
the behavior is undeﬁned.
5.6 Multiplicative operators

[expr.mul]

1 The multiplicative operators *, /, and % group left-to-right.

multiplicative-expression:

pm-expression
multiplicative-expression * pm-expression
multiplicative-expression / pm-expression
multiplicative-expression % pm-expression

2 The operands of * and / shall have arithmetic or unscoped enumeration type; the operands of % shall have
integral or unscoped enumeration type. The usual arithmetic conversions are performed on the operands
and determine the type of the result.

3 The binary * operator indicates multiplication.
4 The binary / operator yields the quotient, and the binary % operator yields the remainder from the division
of the ﬁrst expression by the second. If the second operand of / or % is zero the behavior is undeﬁned. For
integral operands the / operator yields the algebraic quotient with any fractional part discarded;83 if the
quotient a/b is representable in the type of the result, (a/b)*b + a%b is equal to a; otherwise, the behavior
of both a/b and a%b is undeﬁned.
5.7 Additive operators

[expr.add]
1 The additive operators + and - group left-to-right. The usual arithmetic conversions are performed for

operands of arithmetic or enumeration type.
83) This is often called truncation towards zero.

§ 5.7

124

c(cid:13) ISO/IEC

N4296

additive-expression:

multiplicative-expression
additive-expression + multiplicative-expression
additive-expression - multiplicative-expression

For addition, either both operands shall have arithmetic or unscoped enumeration type, or one operand shall
be a pointer to a completely-deﬁned object type and the other shall have integral or unscoped enumeration
type.

2 For subtraction, one of the following shall hold:

(2.1)

(2.2)

(2.3)

—
—

—

both operands have arithmetic or unscoped enumeration type; or
both operands are pointers to cv-qualiﬁed or cv-unqualiﬁed versions of the same completely-deﬁned
object type; or
the left operand is a pointer to a completely-deﬁned object type and the right operand has integral or
unscoped enumeration type.

3 The result of the binary + operator is the sum of the operands. The result of the binary - operator is the

diﬀerence resulting from the subtraction of the second operand from the ﬁrst.

4 When an expression that has integral type is added to or subtracted from a pointer, the result has the type
of the pointer operand. If the pointer operand points to an element of an array object84, and the array is
large enough, the result points to an element oﬀset from the original element such that the diﬀerence of
the subscripts of the resulting and original array elements equals the integral expression. In other words, if
the expression P points to the i-th element of an array object, the expressions (P)+N (equivalently, N+(P))
and (P)-N (where N has the value n) point to, respectively, the i + n-th and i − n-th elements of the array
object, provided they exist. Moreover, if the expression P points to the last element of an array object,
the expression (P)+1 points one past the last element of the array object, and if the expression Q points
one past the last element of an array object, the expression (Q)-1 points to the last element of the array
object. If both the pointer operand and the result point to elements of the same array object, or one past
the last element of the array object, the evaluation shall not produce an overﬂow; otherwise, the behavior is
undeﬁned.

5 When two pointers to elements of the same array object are subtracted, the result is the diﬀerence of the
subscripts of the two array elements. The type of the result is an implementation-deﬁned signed integral
type; this type shall be the same type that is deﬁned as std::ptrdiff_t in the <cstddef> header (18.2). As
with any other arithmetic overﬂow, if the result does not ﬁt in the space provided, the behavior is undeﬁned.
In other words, if the expressions P and Q point to, respectively, the i-th and j-th elements of an array object,
the expression (P)-(Q) has the value i − j provided the value ﬁts in an object of type std::ptrdiff_t.
Moreover, if the expression P points either to an element of an array object or one past the last element of
an array object, and the expression Q points to the last element of the same array object, the expression
((Q)+1)-(P) has the same value as ((Q)-(P))+1 and as -((P)-((Q)+1)), and has the value zero if the
expression P points one past the last element of the array object, even though the expression (Q)+1 does not
point to an element of the array object. Unless both pointers point to elements of the same array object, or
one past the last element of the array object, the behavior is undeﬁned.85

6 For addition or subtraction, if the expressions P or Q have type “pointer to cv T”, where T and the array
element type are not similar (4.4), the behavior is undeﬁned. [ Note: In particular, a pointer to a base class
cannot be used for pointer arithmetic when the array contains objects of a derived class type. — end note ]
84) An object that is not an array element is considered to belong to a single-element array for this purpose; see 5.3.1.
85) Another way to approach pointer arithmetic is ﬁrst to convert the pointer(s) to character pointer(s): In this scheme the
integral value of the expression added to or subtracted from the converted pointer is ﬁrst multiplied by the size of the object
originally pointed to, and the resulting pointer is converted back to the original type. For pointer subtraction, the result of the
diﬀerence between the character pointers is similarly divided by the size of the object originally pointed to.

When viewed in this way, an implementation need only provide one extra byte (which might overlap another object in the

program) just after the end of the object in order to satisfy the “one past the last element” requirements.

§ 5.7

125

c(cid:13) ISO/IEC

N4296

7

If the value 0 is added to or subtracted from a pointer value, the result compares equal to the original pointer
value. If two pointers point to the same object or both point one past the end of the same array or both
are null, and the two pointers are subtracted, the result compares equal to the value 0 converted to the type
std::ptrdiff_t.
5.8 Shift operators

[expr.shift]

1 The shift operators << and >> group left-to-right.

shift-expression:

additive-expression
shift-expression << additive-expression
shift-expression >> additive-expression

The operands shall be of integral or unscoped enumeration type and integral promotions are performed.
The type of the result is that of the promoted left operand. The behavior is undeﬁned if the right operand
is negative, or greater than or equal to the length in bits of the promoted left operand.

2 The value of E1 << E2 is E1 left-shifted E2 bit positions; vacated bits are zero-ﬁlled. If E1 has an unsigned
type, the value of the result is E1 × 2E2, reduced modulo one more than the maximum value representable
in the result type. Otherwise, if E1 has a signed type and non-negative value, and E1 × 2E2 is representable
in the corresponding unsigned type of the result type, then that value, converted to the result type, is the
resulting value; otherwise, the behavior is undeﬁned.

3 The value of E1 >> E2 is E1 right-shifted E2 bit positions. If E1 has an unsigned type or if E1 has a signed
type and a non-negative value, the value of the result is the integral part of the quotient of E1/2E2. If E1
has a signed type and a negative value, the resulting value is implementation-deﬁned.
5.9 Relational operators

[expr.rel]

1 The relational operators group left-to-right.

