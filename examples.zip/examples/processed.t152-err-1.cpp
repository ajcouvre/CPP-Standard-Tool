int main()
{
// OK: x has type int

auto x = 5;
const auto *v = &x, u = 6; // OK: v has type const int*, u has type const int
static auto y = 0.0;
auto int r;
auto f() -> int;
auto g() { return 0.0; }
auto h();

// OK: y has type double
// error: auto is not a storage-class-speciﬁer
// OK: f returns int
// OK: g returns double
// OK: h’s return type will be deduced when it is deﬁned


return 0;
}
