
class C {

void f(int i = 3);
void g(int i, int j = 99);

};

// error: default argument already
void C::f(int i = 3) {
// speciﬁed in class scope
}
void C::g(int i = 88, int j) { // in this translation unit,
}

// C::g can be called with no argument

