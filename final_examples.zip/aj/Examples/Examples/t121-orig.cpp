
int foo(int i) {

static int s = foo(2*i);
return i+1;

}

// recursive call - undeﬁned

