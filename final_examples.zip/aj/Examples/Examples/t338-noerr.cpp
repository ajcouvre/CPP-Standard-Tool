
class A {

friend class B;
int a;

class B {

friend class C;

};

};

class C

{

void f(A* p) {

p->a++;

}
};

class D : public B

void f(A* p) {

p->a++;

}
};

§ 11.3

// despite being a friend of a friend

{

// despite being derived from a friend

263

c(cid:13) ISO/IEC

N4296

11

