
X(std::initializer_list<double> v);

struct X {

};
X x{ 1,2,3 };

The initialization will be implemented in a way roughly equivalent to this:

const double __a[3] = {double{1}, double{2}, double{3}};
X x(std::initializer_list<double>(__a, __a+3));

assuming that the implementation can construct an initializer_list object with a pair of pointers. — end
example ]

6 The array has the same lifetime as any other temporary object (12.2), except that initializing an initializer_-

list object from the array extends the lifetime of the array exactly like binding a reference to a temporary.

typedef std::complex<double> cmplx;
std::vector<cmplx> v1 = { 1, 2, 3 };

void f() {

std::vector<cmplx> v2{ 1, 2, 3 };
std::initializer_list<int> i3 = { 1, 2, 3 };

struct A {

}

};

std::initializer_list<int> i4;
A() : i4{ 1, 2, 3 } {} // creates an A with a dangling reference

For v1 and v2, the initializer_list object is a parameter in a function call, so the array created for {
1, 2, 3 } has full-expression lifetime. For i3, the initializer_list object is a variable, so the array
persists for the lifetime of the variable. For i4, the initializer_list object is initialized in a constructor’s
ctor-initializer, so the array persists only until the constructor exits, and so any use of the elements of i4
