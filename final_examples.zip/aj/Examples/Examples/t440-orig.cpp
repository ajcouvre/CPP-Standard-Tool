
class T { /* ... */ };
int i;

template<class T, T i> void f(T t) {

T t1 = i;
::T t2 = ::i; // global namespace members T and i

// template-parameters T and i

}

136) Since template template-parameters and template template-arguments are treated as types for descriptive purposes, the
terms non-type parameter and non-type argument are used to refer to non-type, non-template parameters and arguments.

§ 14.1

334

c(cid:13) ISO/IEC

N4296

Here, the template f has a type-parameter called T, rather than an unnamed non-type template-parameter
