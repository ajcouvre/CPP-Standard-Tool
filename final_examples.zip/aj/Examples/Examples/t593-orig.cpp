
template <class T> void f(T&&);
template <> void f(int&) { } // #1
template <> void f(int&&) { } // #2
void g(int i) {

// calls f<int&>(int&), i.e., #1
// calls f<int>(int&&), i.e., #2

f(i);
f(0);

}

