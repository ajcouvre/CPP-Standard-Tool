
struct C {

int i;
void f();
const C& operator=( const C& );

§ 3.8

71

c(cid:13) ISO/IEC

};

N4296

const C& C::operator=( const C& other) {

if ( this != &other ) {

this->~C();
new (this) C(other);
f();

// lifetime of *this ends
// new object of type C created
// well-deﬁned

}
return *this;

}

C c1;
C c2;
c1 = c2;
c1.f();

