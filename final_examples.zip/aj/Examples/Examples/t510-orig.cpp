
template<class T> struct Alloc { /* ... */ };
template<class T> using Vec = vector<T, Alloc<T>>;
Vec<int> v;

// same as vector<int, Alloc<int>> v;

template<class T>

void process(Vec<T>& v)
{ /* ... */ }

template<class T>

void process(vector<T, Alloc<T>>& w)
{ /* ... */ }
// error: redeﬁnition

template<template<class> class TT>

void f(TT<int>);

f(v);

// error: Vec not deduced

template<template<class,class> class TT>

void g(TT<int, Alloc<int>>);

g(v);

// OK: TT = vector

§ 14.5.7

363

c(cid:13) ISO/IEC

