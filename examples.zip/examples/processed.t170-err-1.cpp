int main()
{
namespace { int i; }
void f() { i++; }

// unique ::i
// unique ::i++

namespace A {
namespace {

int i;
int j;

}
void g() { i++; }

}

// A:: unique ::i
// A:: unique ::j

// A:: unique ::i++

using namespace A;
void h() {

i++;
A::i++;

§ 7.3.1.1

// error: unique ::i or A:: unique ::i
// A:: unique ::i

171

c(cid:13) ISO/IEC

j++;

}

// A:: unique ::j

N4296


return 0;
}
