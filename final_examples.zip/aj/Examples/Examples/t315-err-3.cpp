
class B { };
class D : private B { friend class Derived; };
struct Base {

virtual void vf1();
virtual void vf2();
virtual void vf3();
vf4();
virtual B*
virtual B*
vf5();
void f();

};

112) Multi-level pointers to classes or references to multi-level pointers to classes are not allowed.

§ 10.3

251

c(cid:13) ISO/IEC

N4296

struct No_good : public Base {

D*

vf4();


};

};

class A;
struct Derived : public Base {

// virtual and overrides Base::vf1()

void vf1();
void vf2(int); // not virtual, hides Base::vf2()
char vf3();
vf4();
D*
A*
vf5();
void f();

// OK: returns pointer to derived class
// error: returns pointer to incomplete class

void g() {

Derived d;
Base* bp = &d;

bp->vf1();
bp->vf2();
bp->f();
B*

p = bp->vf4();

Derived* dp = &d;
D*
q = dp->vf4();

dp->vf2();

}

// standard conversion:
// Derived* to Base*
// calls Derived::vf1()
// calls Base::vf2()
// calls Base::f() (not virtual)
// calls Derived::pf() and converts the
// result to B*

// calls Derived::pf() and does not
// convert the result to B*
// ill-formed: argument mismatch

9

10

