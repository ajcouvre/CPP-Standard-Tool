
3

union U {
int i;
float f;
std::string s;

};

4

Since std::string (21.3) declares non-trivial versions of all of the special member functions, U will have
an implicitly deleted default constructor, copy/move constructor, copy/move assignment operator, and de-
