int main()
{
namespace D {

int d1;

98) During name lookup in a class hierarchy, some ambiguities may be resolved by considering whether one member hides
the other along some paths (10.2). There is no such disambiguation when considering the set of names found as a result of
following using-directives.

§ 7.3.4

181

c(cid:13) ISO/IEC

void f(char);

}
using namespace D;

int d1;

// OK: no conﬂict with D::d1

namespace E {

int e;
void f(int);

}

namespace D {

// namespace extension

int d2;
using namespace E;
void f(int);

}

}

void f() {

d1++;
::d1++;
D::d1++;
d2++;
e++;
f(1);
f(’a’);

// error: ambiguous ::d1 or D::d1?
// OK
// OK
// OK: D::d2
// OK: E::e
// OK: D::f(char)

N4296

[dcl.asm]


return 0;
}
