
// neither trivial nor standard-layout

// trivial but not standard-layout

// standard-layout but not trivial

// both trivial and standard-layout

struct N {

int i;
int j;
virtual ~N();

};

struct T {

int i;
private:
int j;

};

struct SL {

int i;
int j;
~SL();

};

};

struct POD {

int i;
int j;

11

