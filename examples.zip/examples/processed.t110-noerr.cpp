int main()
{
§ 5.20

133

c(cid:13) ISO/IEC

N4296

int x;
struct A {

// not constant

constexpr A(bool b) : m(b?42:x) { }
int m;

};
constexpr int v = A(true).m;

constexpr int w = A(false).m;

constexpr int f1(int k) {

constexpr int x = k;

return x;

}
constexpr int f2(int k) {

int x = k;

return x;

}

constexpr int incr(int &n) {

return ++n;

}
constexpr int g(int k) {

constexpr int x = incr(k);

return x;

}
constexpr int h(int k) {

int x = incr(k);

return x;

}
constexpr int y = h(1);


return 0;
}
