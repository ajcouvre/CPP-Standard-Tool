
remove_const_t<const volatile int> // volatile int
remove_const_t<const int* const>
remove_const_t<const int&>
remove_const_t<const int[3]>

// const int*
// const int&
// int[3]

