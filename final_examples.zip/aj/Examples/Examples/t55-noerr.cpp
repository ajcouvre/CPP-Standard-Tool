
T* t1p;
T* t2p;

// provided that t2p points to an initialized object ...

std::memcpy(t1p, t2p, sizeof(T));

// at this point, every subobject of trivially copyable type in *t1p contains
// the same value as the corresponding subobject in *t2p

