
typedef int& A;
const A aref = 3;

// ill-formed; lvalue reference to non-const initialized with rvalue

