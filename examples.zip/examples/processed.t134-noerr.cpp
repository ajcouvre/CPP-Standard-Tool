int main()
{94) The inline keyword has no eﬀect on the linkage of a function.

§ 7.1.3

152

c(cid:13) ISO/IEC

N4296

typedef struct s { /* ... */ } s;
typedef int I;
typedef int I;
typedef I I;

return 0;
}
