
template <int I, int J> void f(A<I+J>);
template <int K, int L> void f(A<K+L>);

// #1
// same as #1

template <class T> decltype(g(T())) h();
int g(int);
template <class T> decltype(g(T())) h()

{ return g(T()); }

int i = h<int>();

// redeclaration of h() uses the earlier lookup
// ...although the lookup here does ﬁnd g(int)
// template argument substitution fails; g(int)
// was not in scope at the ﬁrst declaration of h()

