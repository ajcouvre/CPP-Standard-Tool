int main()
{
enum class E { a, b };
enum E x = E::a;

// OK


return 0;
}
