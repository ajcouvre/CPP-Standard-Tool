
typedef int A[5], AA[2][3];
typedef const A CA;
typedef const AA CAA;

// type is “array of 5 const int”
// type is “array of 2 array of 3 const int”

