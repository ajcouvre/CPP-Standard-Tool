
5

int f(double);
int f(int);
int (*pfd)(double) = &f;
int (*pfi)(int) = &f;
int (*pfe)(...) = &f;
int (&rfi)(int) = f;
int (&rfd)(double) = f;
void g() {

(int (*)(int))&f;

}

// selects f(double)
// selects f(int)
// error: type mismatch
// selects f(int)
// selects f(double)

// cast expression as selector

The initialization of pfe is ill-formed because no f() with type int(...) has been declared, and not because
of any ambiguity. For another example,

struct X {

int f(int);
static int f(long);

};

= &X::f;
int (X::*p1)(int)
(*p2)(int)
int
= &X::f;
int
(*p3)(long) = &X::f;
int (X::*p4)(long) = &X::f;
int (X::*p5)(int)

= &(X::f);

int

(*p6)(long) = &(X::f);

// OK
// error: mismatch
// OK
// error: mismatch
// error: wrong syntax for
// pointer to member
// OK

6

7

