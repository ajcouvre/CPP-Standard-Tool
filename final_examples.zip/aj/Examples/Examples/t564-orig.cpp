
template<class X, class Y, class Z> X f(Y,Z);
template<class ... Args> void f2();
void g() {

f<int,const char*,double>("aa",3.0);
f<int,const char*>("aa",3.0);
f<int>("aa",3.0);

// Z is deduced to be double

// Y is deduced to be const char*, and
// Z is deduced to be double
// error: X cannot be deduced

f("aa",3.0);
f2<char, short, int, long>(); // OK

}

6

