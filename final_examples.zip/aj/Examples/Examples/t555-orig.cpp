
template<class T> class X;
template<> class X<int>;

// X is a class template

X<int>* p;
X<int> x;

