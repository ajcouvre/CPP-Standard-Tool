
typedef void *p;
typedef const int *q;
typedef int **pi;
typedef const int **pci;

The composite pointer type of p and q is “pointer to const void”; the composite pointer type of pi and
