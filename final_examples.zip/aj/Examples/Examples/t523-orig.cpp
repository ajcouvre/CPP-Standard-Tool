
template<class T> class X {

// meaning X<T>

X* p;
X<T>* p2;
X<int>* p3;
::X* p4;

};

