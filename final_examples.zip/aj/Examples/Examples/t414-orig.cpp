
void Fcn(const int*,
void Fcn(int*, int);

short);

int i;
short s = 0;

void f() {

Fcn(&i, s);

Fcn(&i, 1L);

Fcn(&i,’c’);

}

// is ambiguous because
// &i → int* is better than &i → const int*
// but s → short is also better than s → int

// calls Fcn(int*, int), because
// &i → int* is better than &i → const int*
// and 1L → short and 1L → int are indistinguishable

// calls Fcn(int*, int), because
// &i → int* is better than &i → const int*
// and c → int is better than c → short

132) The algorithm for selecting the best viable function is linear in the number of viable functions. Run a simple tournament
to ﬁnd a function W that is not worse than any opponent it faced. Although another function F that W did not face might be
at least as good as W, F cannot be the best function because at some point in the tournament F encountered another function
G such that F was not better than G. Hence, W is either the best function or there is no best function. So, make a second pass
over the viable functions to verify that W is better than all other functions.

§ 13.3.3

313

c(cid:13) ISO/IEC

N4296

3

