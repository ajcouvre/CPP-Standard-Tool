
§ 14.5.6.2

362

c(cid:13) ISO/IEC

N4296

template<class T, class U> struct A { };

template<class T, class U> void f(U, A<U, T>* p = 0); // #1
class U> void f(U, A<U, U>* p = 0); // #2
template<
// #3
template<class T
> void g(T, T = T());
// #4
template<class T, class... U> void g(T, U ...);

void h() {

f<int>(42, (A<int, int>*)0);
f<int>(42);
g(42);

