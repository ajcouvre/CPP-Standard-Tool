
template<class T = int> struct A {

static int x;

};
template<class U> void g(U) { }

template<> struct A<double> { };
template<> struct A<> { };
template<> void g(char) { }

template<> void g<int>(int) { }
template<> int A<char>::x = 0;

// specialize for T == double
// specialize for T == int
// specialize for U == char
// U is deduced from the parameter type
// specialize for U == int
// specialize for T == char

template<class T = int> struct B {

static int x;

};
template<> int B<>::x = 1;

// specialize for T == int

