int main()
{
auto x = 5, *y = &x;
auto a = 5, b = { 1, 2 };

// OK: auto is int
// error: diﬀerent types for auto

9

10


return 0;
}
