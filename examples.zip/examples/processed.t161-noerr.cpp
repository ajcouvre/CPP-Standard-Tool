int main()
{
template <typename T> auto f(T t) { return t; }
extern template auto f(int); // does not instantiate f<int>
int (*p)(int) = f;

// instantiates f<int> to determine its return type, but an explicit
// instantiation deﬁnition is still required somewhere in the program


return 0;
}
