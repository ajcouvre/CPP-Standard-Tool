int main()
{declarations are well-formed:

3

namespace Company_with_very_long_name { /* ... */ }
namespace CWVLN = Company_with_very_long_name;
namespace CWVLN = Company_with_very_long_name;

// OK: duplicate

§ 7.3.2

173

c(cid:13) ISO/IEC

namespace CWVLN = CWVLN;

N4296


return 0;
}
