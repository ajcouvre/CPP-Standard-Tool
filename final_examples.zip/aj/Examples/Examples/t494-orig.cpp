
template<class T> struct A {

struct C {

template<class T2> struct B { };

};

};

§ 14.5.5

355

c(cid:13) ISO/IEC

N4296

// partial specialization of A<T>::C::B<T2>
template<class T> template<class T2>

struct A<T>::C::B<T2*> { };

A<short>::C::B<int*> absip;

// uses partial specialization

