
template<class T> struct A {

// OK, no typename required

typedef int B;
B b;

};

