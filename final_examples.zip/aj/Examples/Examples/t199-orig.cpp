
2

3

[[ noreturn ]] void f() {

throw "error";

// OK

[[ noreturn ]] void q(int i) { // behavior is undeﬁned if called with an argument <= 0

}

}

if (i > 0)

throw "positive";

