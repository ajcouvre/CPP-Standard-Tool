int main()
{
static_assert(sizeof(long) >= 8, "64-bit code generation required for this library.");


return 0;
}
