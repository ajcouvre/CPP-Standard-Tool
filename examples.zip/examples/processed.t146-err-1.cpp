int main()
{
struct pixel {

int x, y;

};
constexpr pixel ur = { 1294, 1024 };// OK
constexpr pixel origin;

// error: initializer missing


return 0;
}
