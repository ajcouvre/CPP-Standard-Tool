
3

void f(double& a) { a += 3.14; }
// ...
double d = 0;
f(d);

declares a to be a reference parameter of f so the call f(d) will add 3.14 to d.

§ 8.3.2

196

c(cid:13) ISO/IEC

int v[20];
// ...
int& g(int i) { return v[i]; }
// ...
g(3) = 7;

N4296

declares the function g() to return a reference to an integer so g(3)=7 will assign 7 to the fourth element
of the array v. For another example,

struct link {
link* next;

};

link* first;

void h(link*& p) { // p is a reference to pointer

p->next = first;
first = p;
p = 0;

}

}

void k() {

link* q = new link;
h(q);

declares p to be a reference to a pointer to link so h(q) will leave q with the value zero. See also 8.5.3.
