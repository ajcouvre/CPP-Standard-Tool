
struct X {

X&
X
};

operator++();
operator++(int);

// preﬁx ++a
// postﬁx a++

135) Calling operator++ explicitly, as in expressions like a.operator++(2), has no special properties: The argument to
operator++ is 2.

§ 13.5.7

327

c(cid:13) ISO/IEC

N4296

struct Y { };
Y&
Y

operator++(Y&);
operator++(Y&, int);

// preﬁx ++b
// postﬁx b++

void f(X a, Y b) {

++a;
a++;
++b;
b++;

a.operator++();
a.operator++(0);
operator++(b);
operator++(b, 0);

}

