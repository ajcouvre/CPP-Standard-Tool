namespace N {

template<class T> struct A { };
template<class U> void f(U) { }
struct B {

template<class V> friend int g(struct C*); // #3

// #1
// #2

};

}

The declarative regions of T, U and V are the template-declarations on lines #1, #2 and #3, respectively.
But the names A, f, g and C all belong to the same declarative region — namely, the namespace-body of
N. (g is still considered to belong to this declarative region in spite of its being hidden during qualiﬁed and
