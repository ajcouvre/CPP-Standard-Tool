
struct A {
A() : v(42) { } // error

const int& v;

};

9

