
if (x)

int i;

can be equivalently rewritten as

if (x) {
int i;

}

