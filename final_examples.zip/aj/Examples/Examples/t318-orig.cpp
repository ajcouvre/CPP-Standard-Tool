
class point { /* ... */ };
class shape {

point center;

public:

// abstract class

point where() { return center; }
void move(point p) { center=p; draw(); }
virtual void rotate(int) = 0; // pure virtual
// pure virtual
virtual void draw() = 0;

};

};

