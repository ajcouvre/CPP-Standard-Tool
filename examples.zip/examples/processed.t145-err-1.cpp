int main()
{
constexpr int bar(int x, int y) // OK

{ return x + y + x*y; }

// ...
int bar(int x, int y)

{ return x * 2 + 3 * y; }

// error: redeﬁnition of bar


return 0;
}
