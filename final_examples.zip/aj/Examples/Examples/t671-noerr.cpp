
6

// ﬁle: Date.h
#include <iosfwd>
#include <string>
#include <locale>

class Date {
public:

Date(unsigned day, unsigned month, unsigned year);
std::string asString(const std::locale& = std::locale());

std::istream& operator>>(std::istream& s, Date& d);
std::ostream& operator<<(std::ostream& s, Date d);

7 This example illustrates two architectural uses of class locale.
8 The ﬁrst is as a default argument in Date::asString(), where the default is the global (presumably user-

preferred) locale.

9 The second is in the operators << and >>, where a locale “hitchhikes” on another object, in this case a

stream, to the point where it is needed.

// ﬁle: Date.C
#include "Date"
#include <sstream>
std::string Date::asString(const std::locale& l) {

// includes <ctime>

using namespace std;
ostringstream s; s.imbue(l);
s << *this; return s.str();

}

std::istream& operator>>(std::istream& s, Date& d) {

using namespace std;
istream::sentry cerberos(s);
if (cerberos) {

ios_base::iostate err = goodbit;
struct tm t;

§ 22.4.8

740

c(cid:13) ISO/IEC

N4296

use_facet< time_get<char> >(s.getloc()).get_date(s, 0, s, err, &t);
if (!err) d = Date(t.tm_day, t.tm_mon + 1, t.tm_year + 1900);
s.setstate(err);

}
return s;

}

