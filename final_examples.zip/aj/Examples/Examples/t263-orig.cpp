
struct S {

S(std::initializer_list<double>); // #1
// #2
S(std::initializer_list<int>);
// #3
S();
// ...

};
S s1 = { 1.0, 2.0, 3.0 };
S s2 = { 1, 2, 3 };
S s3 = { };

// invoke #1
// invoke #2
// invoke #3

