
enum color { red, yellow, green=20, blue };
color col = red;
color* cp = &col;
if (*cp == blue)

// ...

makes color a type describing various colors, and then declares col as an object of that type, and cp as a
pointer to an object of that type. The possible values of an object of type color are red, yellow, green,
blue; these values can be converted to the integral values 0, 1, 20, and 21. Since enumerations are distinct
types, objects of type color can be assigned only values of type color.

color c = 1;

int i = yellow;

// error: type mismatch,
// no conversion from int to color

// OK: yellow converted to integral value 1
// integral promotion

Note that this implicit enum to int conversion is not provided for a scoped enumeration:

enum class Col { red, yellow, green };
int x = Col::red;
Col y = Col::red;
if (y) { }

// error: no Col to int conversion

// error: no Col to bool conversion

