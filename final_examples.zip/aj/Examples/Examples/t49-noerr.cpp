
// - File 1 -
#include "a.h"
#include "b.h"
B b;
A::A(){

b.Use();

}

// - File 2 -
#include "a.h"
A a;

// - File 3 -
#include "a.h"
#include "b.h"
extern A a;
extern B b;

int main() {

a.Use();
b.Use();

}

5

6

It is implementation-deﬁned whether either a or b is initialized before main is entered or whether the
initializations are delayed until a is ﬁrst odr-used in main. In particular, if a is initialized before main is
entered, it is not guaranteed that b will be initialized before it is odr-used by the initialization of a, that is,
before A::A is called. If, however, a is initialized at some point after the ﬁrst statement of main, b will be
