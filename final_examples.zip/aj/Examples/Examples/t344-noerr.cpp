explicitly call, take the address of or form a pointer to member to an implicitly-declared special member
function.

struct A { };
struct B : A {

B& operator=(const B &);

};
B& B::operator=(const B& s) {

this->A::operator=(s);
return *this;

}

// implicitly declared A::operator=

// well formed

3

