
struct A { };
struct B : virtual A { };
struct C : B { };
struct D : virtual A { D(A*); };
struct X { X(A*); };

struct E : C, D, X {

E() : D(this),

// undeﬁned: upcast from E* to A*
// might use path E* → D* → A*
// but D is not constructed
// D((C*)this), // deﬁned:
// E* → C* deﬁned because E() has started

§ 12.7

286

c(cid:13) ISO/IEC

X(this) {

}
};

