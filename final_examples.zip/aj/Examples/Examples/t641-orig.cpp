
const tuple<int, const int, double, double> t(1, 2, 3.4, 5.6);
// OK. Not ambiguous. i1 == 1
const int &i1 = get<int>(t);
const int &i2 = get<const int>(t); // OK. Not ambiguous. i2 == 2
const double &d = get<double>(t);

// ERROR. ill-formed

