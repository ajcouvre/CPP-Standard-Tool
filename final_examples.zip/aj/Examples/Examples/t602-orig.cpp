
template<class> struct X { };
template<class R, class ... ArgTypes> struct X<R(int, ArgTypes ...)> { };
template<class ... Types> struct Y { };
template<class T, class ... Types> struct Y<T, Types& ...> { };

template<class ... Types> int f(void (*)(Types ...));
void g(int, float);

// uses primary template

X<int> x1;
X<int(int, float, double)> x2; // uses partial specialization; ArgTypes contains float, double
X<int(float, int)> x3;
Y<> y1;
Y<int&, float&, double&> y2;
Y<int, float, double> y3;
int fv = f(g);

// uses primary template
// use primary template; Types is empty
// uses partial specialization; T is int&, Types contains float, double
// uses primary template; Types contains int, float, double
// OK; Types contains int, float

1

2

