template <class T = float> struct B {};
template <template <class TT = float> class T> struct A {

inline void f();
inline void g();

};
template <template <class TT> class T> void A<T>::f() {

T<> t;

// error - TT has no default template argument

}
template <template <class TT = char> class T> void A<T>::g() {

T<> t;

// OK - T<char>

}

15

