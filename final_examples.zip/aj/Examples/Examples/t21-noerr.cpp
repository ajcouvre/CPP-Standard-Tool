const int
{ int

i[i]; }

i = 2;

