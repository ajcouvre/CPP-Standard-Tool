
class X;
void a();
void f() {
class Y;
extern void b();
class A {
// OK, but X is a local class, not ::X
friend class X;
// OK
friend class Y;
// OK, introduces local class Z
friend class Z;
friend void b(); // OK
};
X* px;
Z* pz;

// OK, but ::X is found
// error, no Z is found

}

