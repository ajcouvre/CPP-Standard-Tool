
namespace N {

int i;
int g(int a) { return a; }
int j();
void q();

}
namespace { int l=1; }
// the potential scope of l is from its point of declaration
// to the end of the translation unit

namespace N {

int g(char a) {

return l+a;

}

// overloads N::g(int)
// l is from unnamed namespace

int i;
int j();

// error: duplicate deﬁnition
// OK: duplicate function declaration

int j() {

return g(i);

}
int q();

// OK: deﬁnition of N::j()
// calls N::g(int)


}

