int main()
{
14

(14.1)

(14.2)

(14.3)

(14.4)

—
—
—
—

new T results in a call of operator new(sizeof(T)),
new(2,f) T results in a call of operator new(sizeof(T),2,f),
new T[5] results in a call of operator new[](sizeof(T)*5+x), and
new(2,f) T[5] results in a call of operator new[](sizeof(T)*5+y,2,f).

Here, x and y are non-negative unspeciﬁed values representing array allocation overhead; the result of the
new-expression will be oﬀset by this amount from the value returned by operator new[]. This overhead
may be applied in all array new-expressions, including those referencing the library function operator
new[](std::size_t, void*) and other placement allocation functions. The amount of overhead may vary

return 0;
}
