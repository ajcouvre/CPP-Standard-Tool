int main()
{
const int&& foo();
int i;
struct A { double x; };
const A* a = new A();
decltype(foo()) x1 = 17;
decltype(i) x2;
decltype(a->x) x3;
decltype((a->x)) x4 = x3;

// type is const int&&
// type is int
// type is double
// type is const double&

5


return 0;
}
