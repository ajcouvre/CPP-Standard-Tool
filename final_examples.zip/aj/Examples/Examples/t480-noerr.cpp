
};

};

};

class B {

virtual void f(int);

class D : public B {

template <class T> void f(T); // does not override B::f(int)
// overriding function that calls
void f(int i) { f<>(i); }
// the template instantiation

