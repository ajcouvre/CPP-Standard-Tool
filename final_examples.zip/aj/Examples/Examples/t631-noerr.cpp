std::system_category() values as identical to the POSIX errno values, with additional values as de-
ﬁned by the operating system’s documentation. Implementations for operating systems that are not based
not originate from the operating system, the implementation may provide enums for the associated values.
