
void f() {

int i;
extern void g(int x = i);
// ...

//error

}

};

