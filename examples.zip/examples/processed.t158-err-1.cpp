int main()
{
auto n = n;
auto f();
void g() { &f; }
auto sum(int i) {

if (i == 1)
return i;

else

// error, n’s type is unknown


// sum’s return type is int

return sum(i-1)+i; // OK, sum’s return type has been deduced

}


return 0;
}
