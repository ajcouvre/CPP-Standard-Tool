
#define R "x"
const char* s = R"y";

// ill-formed raw string, not "x" "y"

4

5

