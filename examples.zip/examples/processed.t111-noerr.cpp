int main()
{
bool f() {

}

char array[1 + int(1 + 0.2 - 0.1 - 0.1)]; // Must be evaluated during translation
int size = 1 + int(1 + 0.2 - 0.1 - 0.1);
return sizeof(array) == size;

// May be evaluated at runtime


return 0;
}
