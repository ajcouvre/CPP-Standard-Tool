
3

struct onlydouble {

onlydouble() = delete;
onlydouble(std::intmax_t) = delete;
onlydouble(double);

};

// OK, but redundant

