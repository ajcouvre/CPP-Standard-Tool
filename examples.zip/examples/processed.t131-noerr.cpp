int main()
{
struct S;
extern S a;
extern S f();
extern void g(S);

void h() {

g(a);
f();

}



return 0;
}
