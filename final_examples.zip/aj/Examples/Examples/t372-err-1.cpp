
Given

struct A {

A() = default;
A(int v) : v(v) { }
const int& v = 42;

};
A a1;
A a2(1);

// OK
// OK
// OK

// error: ill-formed binding of temporary to reference
// OK, unfortunately

