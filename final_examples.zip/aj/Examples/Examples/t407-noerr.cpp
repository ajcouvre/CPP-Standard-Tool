
class T {
public:
T();

};

class C : T {
public:

C(int);

};
T a = 1;

// ill-formed: T(C(1)) not tried

7

