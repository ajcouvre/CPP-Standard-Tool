
template<class T = int> class X;
template<class T = int> class X { /*... */ }; // error

