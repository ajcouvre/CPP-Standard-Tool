
std::pair<std::string,int> f(const char* p, int x) {

return {p,x};

}

