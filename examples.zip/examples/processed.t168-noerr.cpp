int main()
{
namespace Q {

namespace V {

void f();
class C { void m(); };

// enclosing namespaces are the global namespace, Q, and Q::V

}
void V::f() { // enclosing namespaces are the global namespace, Q, and Q::V

extern void h(); // ... so this declares Q::V::h

}
void V::C::m() { // enclosing namespaces are the global namespace, Q, and Q::V
}

}

6


return 0;
}
