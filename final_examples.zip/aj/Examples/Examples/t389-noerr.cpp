
N4296

class Thing {
public:

Thing();
~Thing();
Thing(const Thing&);

};

Thing f() {
Thing t;
return t;

}

Thing t2 = f();

Here the criteria for elision can be combined to eliminate two calls to the copy constructor of class Thing:
the copying of the local automatic object t into the temporary object for the return value of function f()
and the copying of that temporary object into object t2. Eﬀectively, the construction of the local object t
can be viewed as directly initializing the global object t2, and that object’s destruction will occur at program
exit. Adding a move constructor to Thing has the same eﬀect, but it is the move construction from the
