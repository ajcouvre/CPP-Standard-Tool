
§ 11.2

260

c(cid:13) ISO/IEC

N4296

class B;
class A {
private:
int i;
friend void f(B*);

};
class B : public A { };
void f(B* p) {

p->i = 1;

}

