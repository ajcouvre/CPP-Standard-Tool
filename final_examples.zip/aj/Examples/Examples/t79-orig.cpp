
§ 5.1.2

98

c(cid:13) ISO/IEC

N4296

void f1(int i) {

int const N = 20;
auto m1 = [=]{

int const M = 30;
auto m2 = [i]{
int x[N][M];
x[0][0] = i;

};

};
struct s1 {

int f;
void work(int n) {

int m = n*n;
int j = 40;
auto m3 = [this,m] {
auto m4 = [&,j] {

int x = n;

x += m;

x += i;
x += f;

};

};

}

};

}

