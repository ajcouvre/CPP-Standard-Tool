
9

struct B1 {

B1(int) { }

};

struct B2 {

B2(double) { }

};

struct D1 : B1 {
using B1::B1;
int x;

};

// implicitly declares D1(int)

void test() {

D1 d(6);
D1 e;

}

struct D2 : B2 {
using B2::B2;
B1 b;

};

// OK: d.x is not initialized

// OK: implicitly declares D2(double)

D2 f(1.0);

// error: B1 has no default constructor

§ 12.9

298

c(cid:13) ISO/IEC

N4296

template< class T >
struct D : T {
using T::T;
~D() { std::clog << "Destroying wrapper" << std::endl; }

// declares all constructors from class T

};

Class template D wraps any class and forwards all of its constructors, while writing a message to the standard
