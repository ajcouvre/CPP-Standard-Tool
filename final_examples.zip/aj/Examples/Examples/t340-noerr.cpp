
class B {
protected:

int i;
static int j;

};

class D1 : public B {
};

class D2 : public B {

friend void fr(B*,D1*,D2*);
void mem(B*,D1*);

};

void fr(B* pb, D1* p1, D2* p2) {

pb->i = 1;
p1->i = 2;
p2->i = 3;

// ill-formed
// ill-formed
// OK (access through a D2)

115) This additional check does not apply to other members, e.g., static data members or enumerator member constants.

§ 11.4

264

c(cid:13) ISO/IEC

N4296

p2->B::i = 4;

int B::* pmi_B = &B::i;
int B::* pmi_B2 = &D2::i;
B::j = 5;
D2::j = 6;

}

// OK (access through a D2, even though
// naming class is B)
// ill-formed
// OK (type of &D2::i is int B::*)
// OK (because refers to static member)
// OK (because refers to static member)

void D2::mem(B* pb, D1* p1) {

pb->i = 1;
p1->i = 2;
i = 3;
B::i = 4;
int B::* pmi_B = &B::i;
int B::* pmi_B2 = &D2::i;
j = 5;
B::j = 6;

void g(B* pb, D1* p1, D2* p2) {

pb->i = 1;
p1->i = 2;
p2->i = 3;

// ill-formed
// ill-formed
// OK (access through this)
// OK (access through this, qualiﬁcation ignored)
// ill-formed
// OK
// OK (because j refers to static member)
// OK (because B::j refers to static member)

// ill-formed
// ill-formed
// ill-formed

}

}

};

};

class B {
public:

virtual int f();

class D : public B {
private:

int f();

