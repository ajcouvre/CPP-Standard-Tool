
struct complex {

complex();
complex(double);
complex(double,double);

};

complex sqrt(complex,complex);

complex a(1);

complex b = a;
complex c = complex(1,2);

complex d = sqrt(b,c);

complex e;

complex f = 3;

complex g = { 1, 2 };

// initialize by a call of
// complex(double)
// initialize by a copy of a
// construct complex(1,2)
// using complex(double,double)
// copy/move it into c
// call sqrt(complex,complex)
// and copy/move the result into d
// initialize by a call of
// complex()
// construct complex(3) using
// complex(double)
// copy/move it into f
// initialize by a call of
// complex(double, double)

