int main()
{
class T {

// ...
public:
T();
T(int);
T(int, int);

};
T(a);
T(*b)();
T(c)=7;
T(d),e,f=3;
extern int h;
T(g)(h,2);

// declaration
// declaration
// declaration
// declaration

// declaration


return 0;
}
