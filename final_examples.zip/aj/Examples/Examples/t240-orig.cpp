
§ 8.5

210

c(cid:13) ISO/IEC

int f(int);
int a = 2;
int b = f(a);
int c(b);

N4296

