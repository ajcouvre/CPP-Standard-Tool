#!/usr/bin/env bash
readonly header=$1
readonly file=/home/aj/aj/examples/tmp.reduction.test.t110-orig.cpp
cat $header /home/aj/aj/examples/t110-orig.cpp > $file 
timeout -s 9 100 g++-trunk  -Wfatal-errors -std=c++14 -c  ${file} &> /dev/null 
exit $?
