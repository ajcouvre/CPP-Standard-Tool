
struct A {

int x;
struct B {

} a = { 1, { 2, 3 } };

int i;
int j;

} b;

