
3

4

5

struct B { };
struct D : B { };
void foo(D* dp) {

}

