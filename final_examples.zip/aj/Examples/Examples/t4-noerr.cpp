
struct S {

S(int i): I(i) { }
int& v() { return I; }

private:
int I;

};

S s1(1);
S s2 = 2;

void f() {

// full-expression is call of S::S(int)
// full-expression is call of S::S(int)

7) Overloaded operators are never assumed to be associative or commutative.

§ 1.9

9

c(cid:13) ISO/IEC

if (S(3).v())

{ }

}

// full-expression includes lvalue-to-rvalue and
// int to bool conversions, performed before
// temporary is deleted at end of full-expression

N4296

11

