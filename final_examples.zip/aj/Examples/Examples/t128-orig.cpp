
3

typedef char* Pc;
static Pc;

// error: name missing

Here, the declaration static Pc is ill-formed because no name was speciﬁed for the static variable of type Pc.
To get a variable called Pc, a type-speciﬁer (other than const or volatile) has to be present to indicate that
the typedef-name Pc is the name being (re)declared, rather than being part of the decl-speciﬁer sequence.
For another example,
void f(const Pc);
void g(const int Pc);

// void f(char* const) (not const char*)
// void g(const int)

4

