
#define N sizeof(T)
char buf[N];
T obj;
std::memcpy(buf, &obj, N);

std::memcpy(&obj, buf, N);

