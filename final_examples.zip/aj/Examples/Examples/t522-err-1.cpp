
template <class T> struct Base { };
template <class T> struct Derived: Base<int>, Base<char> {
// error: ambiguous
// OK

typename Derived::Base b;
typename Derived::Base<double> d;

};

