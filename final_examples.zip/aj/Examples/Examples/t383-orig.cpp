
4

struct X {

X(const X&);
X(X&);
X(X&&);
X(const X&&);

};

// OK

// OK, but possibly not sensible

5

