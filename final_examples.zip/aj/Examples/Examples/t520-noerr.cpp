
template<template<class> class T> class A { };
template<class T> class Y;
template<> class Y<int> {

// meaning Y<int>
// meaning Y<char>
// meaning A<::Y>

Y* p;
Y<char>* q;
A<Y>* a;
class B {

};

};

template<class> friend class Y;

// meaning ::Y

