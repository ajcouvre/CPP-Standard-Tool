
class C { };
void f(int(C)) { }

int g(C);

// void f(int(*fp)(C c)) { }
// not: void f(int C);

void foo() {

f(1);
f(g);

}

// error: cannot convert 1 to function pointer
// OK

For another example,

class C { };
void h(int *(C[10]));

// void h(int *(*_fp)(C _parm[10]));
// not: void h(int *C[10]);

