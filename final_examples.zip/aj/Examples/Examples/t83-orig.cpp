
void f3() {

float x, &r = x;
[=] {

decltype(x) y1;
decltype((x)) y2 = y1; // y2 has type float const& because this lambda

// x and r are not captured (appearance in a decltype operand is not an odr-use)
// y1 has type float

decltype(r) r1 = y1;
decltype((r)) r2 = y2; // r2 has type float const&

// is not mutable and x is an lvalue
// r1 has type float& (transformation not considered)

§ 5.1.2

100

c(cid:13) ISO/IEC

};

}

