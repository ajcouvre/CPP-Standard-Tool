
template<class T> struct X : B<T> {

typename T::A* pa;
void f(B<T>* pb) {

static int i = B<T>::i;
pb->j++;

}
};

the base class name B<T>, the type name T::A, the names B<T>::i and pb->j explicitly depend on the
