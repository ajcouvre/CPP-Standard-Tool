int main()
{
void f();

namespace A {

void g();

}

namespace X {
using ::f;
using A::g;

}

// global f
// A’s g

void h()
{

X::f();
X::g();

}

// calls ::f
// calls A::g


return 0;
}
