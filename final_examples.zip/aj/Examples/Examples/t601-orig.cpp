
template <template <class T> class X> struct A { };
template <template <class T> class X> void f(A<X>) { }
template<class T> struct B { };

143) Although the template-argument corresponding to a template-parameter of type bool may be deduced from an array
bound, the resulting value will always be true because the array bound will be non-zero.

§ 14.8.2.5

410

c(cid:13) ISO/IEC

A<B> ab;
f(ab);

// calls f(A<B>)

N4296

21

