int main()
{
auto x = 5, *y = &x;
auto a = 5, b = { 1, 2 };

// OK: auto is int

9

10


return 0;
}
