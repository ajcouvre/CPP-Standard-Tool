int main()
{
struct A {};
struct B : A { int x; };
struct C : A { int x; };

int A::*bx = (int(A::*))&B::x;
int A::*cx = (int(A::*))&C::x;

bool b1 = (bx == cx);

// unspeciﬁed

(3.5)

(3.6)

—
—


return 0;
}
