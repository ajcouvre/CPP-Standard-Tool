
template<class ... Types> void f(Types ... args);

f();
f(1);
f(2, 1.0);

