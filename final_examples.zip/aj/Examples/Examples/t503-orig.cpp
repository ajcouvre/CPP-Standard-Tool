
template <int I, int J> A<I+J> f(A<I>, A<J>);
template <int K, int L> A<K+L> f(A<K>, A<L>);
template <int I, int J> A<I-J> f(A<I>, A<J>);

// #1
// same as #1
// diﬀerent from #1

