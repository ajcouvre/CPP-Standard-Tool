
template <class T, T*> int f(int);
int i2 = f<int,1>(0);

// can’t conv 1 to int*

(8.10)

(8.11)

