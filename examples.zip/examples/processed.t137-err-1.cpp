int main()
{
// OK

class complex { /* ... */ };
typedef int complex;

// error: redeﬁnition

4

5

6


return 0;
}
