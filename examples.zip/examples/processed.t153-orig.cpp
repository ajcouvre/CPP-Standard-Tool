int main()
{
§ 7.1.6.4

163

N4296

// decltype(x1) is std::initializer_list<int>
// error: cannot deduce element type
// error: not a single element
// decltype(x4) is std::initializer_list<int>
// decltype(x5) is int

c(cid:13) ISO/IEC

auto x1 = { 1, 2 };
auto x2 = { 1, 2.0 };
auto x3{ 1, 2 };
auto x4 = { 3 };
auto x5{ 3 };


return 0;
}
