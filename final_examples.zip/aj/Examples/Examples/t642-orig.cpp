
2

template<class F, class Tuple, std::size_t... I>

decltype(auto) apply_impl(F&& f, Tuple&& t, index_sequence<I...>) {
return std::forward<F>(f)(std::get<I>(std::forward<Tuple>(t))...);

}

}

template<class F, class Tuple>

decltype(auto) apply(F&& f, Tuple&& t) {

using Indices = make_index_sequence<std::tuple_size<std::decay_t<Tuple>>::value>;
return apply_impl(std::forward<F>(f), std::forward<Tuple>(t), Indices());

§ 20.5.1

533

c(cid:13) ISO/IEC

N4296

