int main()
{
namespace X {

void f() { /* ... */ } // OK: introduces X::f()

namespace M {

void g();

}
using M::g;
void g();

}

// OK: introduces X::M::g()

// error: conﬂicts with X::M::g()


return 0;
}
