
template<class T, class... U> void f(T, U...);
template<class T
template<class T, class... U> void g(T*, U...);
template<class T

> void f(T);

> void g(T);

}

}

void h(int i) {

f(&i);
g(&i);

// calls #2
// error: ambiguous
// error: ambiguous

// #1
// #2
// #3
// #4

// error: ambiguous
// OK: calls #3

