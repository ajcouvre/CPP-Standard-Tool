int j = 24;
int main() {

2

int i = j, j;
j = 42;

}

the identiﬁer j is declared twice as a name (and used twice). The declarative region of the ﬁrst j includes
the entire example. The potential scope of the ﬁrst j begins immediately after that j and extends to the
end of the program, but its (actual) scope excludes the text between the , and the }. The declarative region
of the second declaration of j (the j immediately before the semicolon) includes all the text between { and
}, but its potential scope excludes the declaration of i. The scope of the second declaration of j is the same
