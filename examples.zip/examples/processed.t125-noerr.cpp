int main()
{
[[noreturn]] void f [[noreturn]] (); // OK


return 0;
}
