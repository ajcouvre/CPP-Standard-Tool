volatile int, whereas remove_const_t<const int*> evaluates to
