
template<class T, int i> class Y {

// error: template-parameter redeclared

// error: template-parameter redeclared

int T;
void f() {
char T;

}
};

template<class X> class X;

// error: template-parameter redeclared

7

