

struct A {



const int& v;



};



9



