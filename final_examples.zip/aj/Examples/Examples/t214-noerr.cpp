
8

int x[3][5];

Here x is a 3 × 5 array of integers. When x appears in an expression, it is converted to a pointer to (the
ﬁrst of three) ﬁve-membered arrays of integers. In the expression x[i] which is equivalent to *(x+i), x is
ﬁrst converted to a pointer as described; then x+i is converted to the type of x, which involves multiplying
i by the length of the object to which the pointer points, namely ﬁve integer objects. The results are added
and indirection applied to yield an array (of ﬁve integers), which in turn is converted to a pointer to the
ﬁrst of the integers. If there is another subscript the same argument applies again; this time the result is an
