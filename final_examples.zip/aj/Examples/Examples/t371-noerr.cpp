
struct A {

int i = /* some integer expression with side eﬀects */ ;
A(int arg) : i(arg) { }
// ...

};

the A(int) constructor will simply initialize i to the value of arg, and the side eﬀects in i’s brace-or-equal-
