
void f() {

union { int a; const char* p; };
a = 1;
p = "Jennifer";

}

}

Here a and p are used like ordinary (nonmember) variables, but since they are union members they have
