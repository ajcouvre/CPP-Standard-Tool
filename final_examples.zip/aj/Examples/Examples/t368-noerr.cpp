
struct B1 { B1(int); /* ... */ };
struct B2 { B2(int); /* ... */ };
struct D : B1, B2 {

D(int);
B1 b;
const int c;

};

D::D(int a) : B2(a+1), B1(a+2), c(a+3), b(a+4)

{ /* ... */ }

D d(10);

