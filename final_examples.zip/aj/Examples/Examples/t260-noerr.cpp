
cv1 shall be the same cv-qualiﬁcation as, or greater cv-qualiﬁcation than, cv2; and
if the reference is an rvalue reference, the initializer expression shall not be an lvalue.

struct Banana { };
struct Enigma { operator const Banana(); };
struct Alaska { operator Banana&(); };
void enigmatic() {

typedef const Banana ConstBanana;
Banana &&banana1 = ConstBanana(); // ill-formed
// ill-formed
Banana &&banana2 = Enigma();
// ill-formed
Banana &&banana3 = Alaska();

}

const double& rcd2 = 2;
double&& rrd = 2;
const volatile int cvi = 1;
const int& r2 = cvi;
struct A { operator volatile int&(); } a;
const int& r3 = a;

// rcd2 refers to temporary with value 2.0
// rrd refers to temporary with value 2.0


// from result of conversion function



// rrd3 refers to temporary with value 2.0

double d2 = 1.0;
double&& rrd2 = d2;
struct X { operator int&(); };
int&& rri2 = X();
int i3 = 2;
double&& rrd3 = i3;

