int main()
{
struct A {

template <class T> void f(T);
template <class T> struct X { };

// ill-formed
// ill-formed

};
struct B : A {

using A::f<double>;
using A::X<int>;

};


return 0;
}
