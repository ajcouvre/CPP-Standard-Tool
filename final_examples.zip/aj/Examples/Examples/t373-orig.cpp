
14

struct V {

V();
V(int);

};

struct A : virtual V {

A();
A(int);

B();
B(int);

};

};

struct B : virtual V {

struct C : A, B, virtual V {

C();
C(int);

};
A::A(int i) : V(i) { /* ... */ }
B::B(int i) { /* ... */ }
C::C(int i) { /* ... */ }

V v(1);
A a(2);
B b(3);
C c(4);

