*E is an lvalue expression referring to the object or function to which E points. As another example,
