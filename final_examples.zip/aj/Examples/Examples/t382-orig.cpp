
struct Y {

Y(const Y&);
Y(Y&&);

};
extern Y f(int);
Y d(f(1));
Y e = d;

// calls Y(Y&&)
// calls Y(const Y&)

