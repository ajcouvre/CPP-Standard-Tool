int main()
{
struct S {

};

enum E : int {};


return 0;
}
