int main()
{
struct S {

// Placement allocation function:
static void* operator new(std::size_t, std::size_t);

// Usual (non-placement) deallocation function:
static void operator delete(void*, std::size_t);

};

S* p = new (0) S;

// ill-formed: non-placement deallocation function matches
// placement allocation function

23


return 0;
}
