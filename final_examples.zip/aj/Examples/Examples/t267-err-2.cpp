
struct S {

S(std::initializer_list<double>); // #1
// #2
S(const std::string&);
// ...

};
const S& r1 = { 1, 2, 3.0 };
const S& r2 { "Spinach" };
S& r3 = { 1, 2, 3 };
const int& i1 = { 1 };
const int& i2 = { 1.1 };
const int (&iar)[2] = { 1, 2 };

// OK: invoke #1
// OK: invoke #2
// OK
// error: narrowing
// OK: iar is bound to temporary array

(3.9)

—

