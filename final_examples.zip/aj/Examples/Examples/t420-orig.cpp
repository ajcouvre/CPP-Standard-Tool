
void f(std::initializer_list<int>);
f( {} );
f( {1,2,3} );
f( {’a’,’b’} );
f( {1.0} );

// OK: f(initializer_list<int>) identity conversion
// OK: f(initializer_list<int>) identity conversion
// OK: f(initializer_list<int>) integral promotion
// error: narrowing

struct A {

// #1
A(std::initializer_list<double>);
A(std::initializer_list<complex<double>>); // #2
// #3
A(std::initializer_list<std::string>);

};
A a{ 1.0,2.0 };

void g(A);
g({ "foo", "bar" });

typedef int IA[3];
void h(const IA&);
h({ 1, 2, 3 });

