
8

// OK
void operator "" _km(long double);
string operator "" _i18n(const char*, std::size_t); // OK
// OK: UCN for lowercase pi
template <char...> double operator "" _\u03C0();
// OK
float operator ""_e(const char*);
// error: reserved literal suﬃx (17.6.4.3.4, 2.13.8)
float operator ""E(const char*);
// OK: does not use the reserved identiﬁer _Bq (2.10)
double operator""_Bq(long double);
// uses the reserved identiﬁer _Bq (2.10)
double operator"" _Bq(long double);
// error: non-empty string-literal
float operator " " B(const char*);
// error: invalid literal suﬃx identiﬁer
string operator "" 5X(const char*, std::size_t);
// error: invalid parameter-declaration-clause
double operator "" _miles(double);
template <char...> int operator "" _j(const char*); // error: invalid parameter-declaration-clause
extern "C" void operator "" _m(long double);

// error: C language linkage

