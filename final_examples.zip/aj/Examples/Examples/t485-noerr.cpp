
template<typename...> struct Tuple {};
template<typename T1, typename T2> struct Pair {};

template<class ... Args1> struct zip {

template<class ... Args2> struct with {

typedef Tuple<Pair<Args1, Args2> ... > type;

};

};

typedef zip<short, int>::with<unsigned short, unsigned>::type T1;

// T1 is Tuple<Pair<short, unsigned short>, Pair<int, unsigned>>

typedef zip<short>::with<unsigned short, unsigned>::type T2;


// OK: Args is expanded by the function parameter pack args

f(const_cast<const Args*>(&args)...); // OK: “Args” and “args” are expanded
f(5 ...);
f(args);
f(h(args ...) + args ...);

// OK: ﬁrst “args” expanded within h, second
// “args” expanded within f

template<class ... Args>
void g(Args ... args) {

}

