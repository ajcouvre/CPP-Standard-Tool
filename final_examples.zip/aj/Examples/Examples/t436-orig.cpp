
Z operator[](std::initializer_list<int>);

struct X {

};
X x;
x[{1,2,3}] = 7;
int a[10];
a[{1,2,3}] = 7;

// OK: meaning x.operator[]({1,2,3})

// error: built-in subscript operator

