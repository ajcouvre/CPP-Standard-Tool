
template<class T> void f(std::initializer_list<T>);
f({1,2,3});
f({1,"asdf"});

// T deduced to int

template<class T> void g(T);
g({1,2,3});

// error: no argument deduced for T

template<class T, int N> void h(T const(&)[N]);
h({1,2,3});

// T deduced to int, N deduced to 3

template<class T> void j(T const(&)[3]);
j({42});

// T deduced to int, array bound not considered

struct Aggr { int i; int j; };
template<int N> void k(Aggr const(&)[N]);
k({1,2,3});
k({{1},{2},{3}});

// OK, N deduced to 3

template<int M, int N> void m(int const(&)[M][N]);
m({{1,2},{3,4}});

// M and N both deduced to 2

template<class T, int N> void n(T const(&)[N], T);
// OK, T is Aggr, N is 3
n({{1},{2},{3}},Aggr());

