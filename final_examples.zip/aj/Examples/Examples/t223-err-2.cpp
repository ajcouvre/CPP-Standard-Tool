
void g(int = 0, ...);

void f(int, int);
void f(int, int = 7);
void h() {

f(3);
void f(int = 1, int);

}
void m() {

void f(int, int);
f(4);
void f(int, int = 5);
f(4);
void f(int, int = 5);

}
void n() {

f(6);

}

// OK, ellipsis is not a parameter so it can follow
// a parameter with a default argument

// OK, calls f(3, 7)
// from surrounding scope

// has no defaults
// error: wrong number of arguments
// OK
// OK, calls f(4, 5);
// same value

// OK, calls f(6, 7)

